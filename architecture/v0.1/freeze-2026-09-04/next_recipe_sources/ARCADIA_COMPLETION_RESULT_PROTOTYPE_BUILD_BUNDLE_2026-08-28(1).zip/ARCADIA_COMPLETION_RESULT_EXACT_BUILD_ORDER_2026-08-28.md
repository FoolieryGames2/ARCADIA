# A.R.C.A.D.I.A. — COMPLETION + RESULT EXACT PROTOTYPE BUILD ORDER
## Recipes 7 and 8
**Date:** 2026-08-28  
**Rule:** Do not skip gates. Do not integrate Result until Completion is independently passing.

---

# PHASE C7-A — Completion foundation

- [ ] C7-A01 Freeze Persistence handoff contract and hashes.
- [ ] C7-A02 Add Completion policy snapshot model.
- [ ] C7-A03 Add terminal status enum exactly: SATISFIED / PARTIALLY_SATISFIED / BLOCKED / FAILED.
- [ ] C7-A04 Add Completion artifact aliases CA/CP/FSP with UUID identity.
- [ ] C7-A05 Define typed `RequirementClosureBundle`.
- [ ] C7-A06 Define Closure Signal Pack.
- [ ] C7-A07 Define Final Standing Packet typed model.
- [ ] C7-A08 Add canonical hash/replay hooks.

**Gate:** all models round-trip and hash deterministically.

# PHASE C7-B — Closure repository + graph

- [ ] C7-B01 Implement requirement-linked SQLite artifact queries.
- [ ] C7-B02 Implement exact Rxxx -> Context ref collection.
- [ ] C7-B03 Implement Rxxx -> Decision/Wxxx collection.
- [ ] C7-B04 Implement Wxxx -> TRQ/REC/unexecuted-state collection.
- [ ] C7-B05 Implement work -> EF/Reconciliation collection.
- [ ] C7-B06 Implement Rxxx -> Persistence obligation/result/PRC collection.
- [ ] C7-B07 Build NetworkX provenance graph from validated artifact links.
- [ ] C7-B08 Add reachability checks.
- [ ] C7-B09 Add orphan support/work checks.
- [ ] C7-B10 Add cycle checks where forbidden.
- [ ] C7-B11 Build per-Rxxx bounded provenance subgraph.
- [ ] C7-B12 Hash graph/subgraph projection.

**Gate:** exact closure lineage is mechanically reproducible.

# PHASE C7-C — Closure signals

- [ ] C7-C01 Work expected/executed/unexecuted sets.
- [ ] C7-C02 Reconciled/established/partial/conflict sets.
- [ ] C7-C03 Open gap/DN/RRQ counters.
- [ ] C7-C04 Required Persistence obligation sets.
- [ ] C7-C05 Persistence committed/no-change/blocked/failed sets.
- [ ] C7-C06 Upstream integrity flags.
- [ ] C7-C07 Build final Closure Signal Pack.
- [ ] C7-C08 Host closure bundle hash validation.

**Gate:** no AI needed to answer mechanical closure facts.

# PHASE C7-D — Completion Assessor

- [ ] C7-D01 Define Assessor input JSON Schema.
- [ ] C7-D02 Define Assessor output JSON Schema.
- [ ] C7-D03 Write canonical Completion Assessor prompt.
- [ ] C7-D04 Implement fresh-KV Assessor runner.
- [ ] C7-D05 Implement ref validator.
- [ ] C7-D06 Implement terminal enum validator.
- [ ] C7-D07 Implement SATISFIED/material-gap consistency gate.
- [ ] C7-D08 Implement PARTIAL/nonempty-fulfillment gate.
- [ ] C7-D09 Implement BLOCKED/blocker gate.
- [ ] C7-D10 Implement FAILED/failure-basis gate.
- [ ] C7-D11 Implement result-guidance ref validation.
- [ ] C7-D12 Implement bounded repair x2.
- [ ] C7-D13 Build independent fixture suite.
- [ ] C7-D14 Run SATISFIED/PARTIAL/BLOCKED/FAILED contrast tests.

**Gate:** Assessor passes independently for one Rxxx at a time.

# PHASE C7-E — Completion Composer

- [ ] C7-E01 Define Composer input schema.
- [ ] C7-E02 Define Composer output schema.
- [ ] C7-E03 Write canonical Completion Composer prompt.
- [ ] C7-E04 Implement fresh-KV Composer runner.
- [ ] C7-E05 Implement exact Rxxx coverage gate.
- [ ] C7-E06 Implement CA ref gate.
- [ ] C7-E07 Implement immutable-status preservation gate.
- [ ] C7-E08 Implement overall posture validation.
- [ ] C7-E09 Implement shared fact/blocker/failure ref validation.
- [ ] C7-E10 Implement disclosure/protected-literal seed validation.
- [ ] C7-E11 Implement bounded repair x2.
- [ ] C7-E12 Build Composer fixtures.

**Gate:** Composer can organize but cannot mutate any CA terminal standing.

# PHASE C7-F — Final Standing Packet

- [ ] C7-F01 Host builds immutable FSP from validated CP.
- [ ] C7-F02 Add basis hashes.
- [ ] C7-F03 Add per-Rxxx user-facing projections.
- [ ] C7-F04 Add disclosure seeds.
- [ ] C7-F05 Add protected literal seeds.
- [ ] C7-F06 Add FSP validation.
- [ ] C7-F07 Append Completion artifacts to technical ledger.
- [ ] C7-F08 Freeze Completion -> Result handoff.

**Completion gate:** FSP is hash-stable and all Completion adversarial tests pass.

---

# PHASE R8-A — Result host foundation

- [ ] R8-A01 Add Result policy snapshot.
- [ ] R8-A02 Add RCM/RST/PUB artifact identities.
- [ ] R8-A03 Define Result Comment Packet.
- [ ] R8-A04 Define Result Comment output.
- [ ] R8-A05 Define final Howard input.
- [ ] R8-A06 Define RST artifact.
- [ ] R8-A07 Define PUB receipt.
- [ ] R8-A08 Validate FSP hash at Result entry.

**Gate:** no Howard call until FSP is valid.

# PHASE R8-B — Disclosure / literal modules

- [ ] R8-B01 Build MUST_MENTION/MAY_MENTION/DO_NOT_EXPOSE map.
- [ ] R8-B02 Build protected literal extractor.
- [ ] R8-B03 Add EXACT_REQUIRED vs DISPLAY_FLEXIBLE policy.
- [ ] R8-B04 Add regex number/date/time/version extraction.
- [ ] R8-B05 Add URL/path/hash/internal-ID extraction.
- [ ] R8-B06 Add internal ID guard patterns.
- [ ] R8-B07 Add spaCy sentence/entity/noun-chunk signal pack.
- [ ] R8-B08 Add RapidFuzz protected-name corruption signal.
- [ ] R8-B09 Add MUST_MENTION coverage module.
- [ ] R8-B10 Add response budget calculator.

**Gate:** modules can validate hand-authored response fixtures without Howard.

# PHASE R8-C — Howard per-requirement comments

- [ ] R8-C01 Write Conversational Howard Result Comment prompt.
- [ ] R8-C02 Build one bounded packet per user-facing Rxxx.
- [ ] R8-C03 Run Howard fresh-KV per requirement.
- [ ] R8-C04 Validate standing echo.
- [ ] R8-C05 Validate allowed refs.
- [ ] R8-C06 Validate protected literals.
- [ ] R8-C07 Validate internal-ID leakage.
- [ ] R8-C08 Validate MUST_MENTION coverage.
- [ ] R8-C09 Validate must-not-claim list.
- [ ] R8-C10 Implement bounded wording repair x2.
- [ ] R8-C11 Implement deterministic safe comment fallback.
- [ ] R8-C12 Persist validated RCM artifacts in ledger.

**Gate:** every user-facing Rxxx has a validated comment or safe deterministic fallback.

# PHASE R8-D — Final Howard composition

- [ ] R8-D01 Clear KV after all comment passes.
- [ ] R8-D02 Write Conversational Howard Final Result prompt.
- [ ] R8-D03 Build bounded final input from FSP + validated comments.
- [ ] R8-D04 Run final Howard composition.
- [ ] R8-D05 Run internal-ID scan.
- [ ] R8-D06 Run literal extraction/lock check.
- [ ] R8-D07 Run spaCy surface inspection.
- [ ] R8-D08 Run RapidFuzz name signal.
- [ ] R8-D09 Run MUST_MENTION coverage.
- [ ] R8-D10 Run must-not-claim/standing consistency checks.
- [ ] R8-D11 Run response budget check.
- [ ] R8-D12 Implement bounded final repair x2.
- [ ] R8-D13 Implement deterministic safe final fallback.
- [ ] R8-D14 Freeze validated RST artifact + hash.

**Gate:** exact response text is valid before transport.

# PHASE R8-E — Publication

- [ ] R8-E01 Implement publication transport interface.
- [ ] R8-E02 Send exact RST response bytes/text.
- [ ] R8-E03 Require transport acknowledgment where supported.
- [ ] R8-E04 On success, write exact published text into conversation_turns.
- [ ] R8-E05 Verify transcript hash == RST response hash.
- [ ] R8-E06 Set turn status COMPLETED only after successful publication path.
- [ ] R8-E07 Increment transcript_commit_seq exactly once.
- [ ] R8-E08 Create immutable PUB receipt.
- [ ] R8-E09 Keep failed drafts out of normal transcript.
- [ ] R8-E10 Expose exact final text to user.

**Gate:** Recipe 0 can retrieve exact published exchange on next turn.

---

# FINAL C7/R8 END-TO-END STRESS GATE

- [ ] CR-01 one simple satisfied informational request
- [ ] CR-02 satisfied verified external operation
- [ ] CR-03 find + remember both satisfied
- [ ] CR-04 find satisfied / remember failed
- [ ] CR-05 duplicate remember -> no-change but satisfied
- [ ] CR-06 advisory Persistence failure does not fail user requirement
- [ ] CR-07 genuine partial
- [ ] CR-08 blocked missing user prerequisite
- [ ] CR-09 failed required tool operation
- [ ] CR-10 unresolved conflict
- [ ] CR-11 multiple independent Rxxx
- [ ] CR-12 shared Wxxx supports multiple Rxxx
- [ ] CR-13 open required RRQ prevents false satisfaction
- [ ] CR-14 open required DN prevents premature completion
- [ ] CR-15 provenance orphan rejected
- [ ] CR-16 invented Completion support ref rejected
- [ ] CR-17 Composer status mutation rejected
- [ ] CR-18 FSP tamper rejected
- [ ] CR-19 Howard exact version corruption rejected
- [ ] CR-20 Howard exact name corruption rejected
- [ ] CR-21 Howard fabricated URL/path rejected
- [ ] CR-22 Howard hides blocker rejected
- [ ] CR-23 Howard says saved when PRC failed rejected
- [ ] CR-24 internal IDs suppressed
- [ ] CR-25 comment repair succeeds
- [ ] CR-26 comment repair exhaustion uses safe fallback
- [ ] CR-27 final repair succeeds
- [ ] CR-28 final repair exhaustion uses safe fallback
- [ ] CR-29 exact published response == transcript response
- [ ] CR-30 failed transport does not mark turn completed
- [ ] CR-31 failed drafts absent from normal transcript
- [ ] CR-32 Recipe 0 next-turn retrieval sees exact published response
- [ ] CR-33 full Recipe 0 -> 8 trace replay/hash validation

**Final gate:** Prototype final spine is not frozen until CR-01 through CR-33 pass.
