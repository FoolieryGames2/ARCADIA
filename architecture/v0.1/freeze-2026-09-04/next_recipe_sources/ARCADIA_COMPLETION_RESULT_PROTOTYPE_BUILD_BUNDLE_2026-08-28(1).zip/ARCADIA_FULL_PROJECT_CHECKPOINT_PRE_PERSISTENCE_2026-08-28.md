# A.R.C.A.D.I.A. — FULL PROJECT CHECKPOINT
## Six-Recipe Pre-Persistence Prototype Integration Specification

**Project:** A.R.C.A.D.I.A. — Adaptive Runtime for Compartmentalized Agents, Decisions, Interaction & Automation  
**Checkpoint date:** 2026-08-28  
**Status:** PRE-PERSISTENCE INTEGRATION CHECKPOINT — READY TO BUILD AFTER THIS PATCH  
**Scope:** Recipe 0 through Recipe 5 only  
**Next design target:** Recipe 6 — Persistence  
**Purpose:** Combine the current locked Intent, Context, Decision, Tool / Execution, and Reconciliation specifications with the newly agreed Conversation Resolver and the stress-test corrections required before Persistence is designed or implemented.

---

# 0. SOURCE BASELINE AND SUPERSESSION POLICY

This checkpoint is based on the current prototype specifications:

1. `HOWARD_INTENT_RECIPE_PROTOTYPE_BUILD_SPEC_2026-08-28.md`
2. `HOWARD_CONTEXT_RECIPE_PROTOTYPE_BUILD_SPEC_2026-08-28.md`
3. `ARCADIA_DECISION_RECIPE_PROTOTYPE_BUILD_SPEC_2026-08-28.md`
4. `ARCADIA_TOOL_EXECUTION_PROTOTYPE_BUILD_SPEC_2026-08-28.md`
5. `ARCADIA_RECONCILIATION_RECIPE_PROTOTYPE_BUILD_SPEC_2026-08-28.md`
6. Current design discussion establishing Recipe 0 — Conversation Resolver and the pre-Persistence stress-test patch.

This checkpoint does **not** erase the individual recipe specifications. They remain detailed source references for the internals of their slices.

Where this checkpoint explicitly conflicts with an older recipe statement, **this checkpoint supersedes that statement for the integrated prototype**.

The most important supersessions are:

```text
OLD / SUPERSEDED
Downstream evidence may produce an updated Intent revision.

NEW / AUTHORITATIVE
Downstream discovery never mutates the accepted original Intent artifact or Rxxx requirements.
Context appends resolutions/revisions while preserving the original Intent artifact.
```

```text
OLD / AMBIGUOUS
A Context revision can become official before the mandatory Howard promotion comment.

NEW / AUTHORITATIVE
PROPOSED -> CONTEXT_ACCEPTED -> PROMOTION_PENDING_COMMENT -> ACTIVE.
The previous active revision remains active until the new revision reaches ACTIVE.
```

```text
OLD / INCOMPLETE
Decision validates Context hash but does not explicitly require Context readiness.

NEW / AUTHORITATIVE
Normal Decision execution requires context_handoff.ready_for_next_stage == true.
```

---

# 1. CHECKPOINT VERDICT

The six-slice pre-Persistence architecture is retained.

No recipe is being collapsed or reassigned.

The integrated spine is:

```text
[0] CONVERSATION RESOLVER
    What prior conversation is required to interpret this raw prompt?
              |
              v
[1] INTENT
    What did the user communicate?
              |
              v
[2] CONTEXT
    What grounded state do we have?
              |
              v
[3] DECISION
    What work actually needs to happen?
              |
              v
[4] TOOL / EXECUTION
    What operations actually occurred?
              |
              v
[5] RECONCILIATION
    What did the returned work actually establish?
              |
              v
[6] PERSISTENCE — NEXT DESIGN
    What should become durable semantic state?
              |
              v
[7] COMPLETION — LATER DESIGN
    Which Rxxx requirements are terminally satisfied / blocked / failed?
              |
              v
RESULT
```

Recipe 0 is new.

Recipes 1–5 preserve their existing specialist boundaries but receive the cross-recipe patches defined here.

---

# 2. SYSTEM-WIDE AUTHORITY MODEL

A.R.C.A.D.I.A. remains host-heavy and compartmentalized.

| Layer | Owns | Must not own |
|---|---|---|
| Conversation Resolver | Minimum sufficient conversational-history scope | Durable semantic memory, Intent, tools |
| Intent | What the user communicated in the current turn | Historical retrieval, durable memory truth, execution |
| Context | Active grounded working state and provenance | Intent mutation, external tool execution, durable writes |
| Decision | Planned work and evidence targets | Execution, semantic interpretation of returned evidence, SQLite writes |
| Execution Host | Whether an authorized operation actually occurred | Whether returned evidence semantically satisfies the task |
| Reconciliation | What receipts/results actually establish | Intent mutation, tool execution, SQLite commits, terminal completion |
| Persistence Host | Future durable semantic commits | Conversation transcript selection, execution truth, terminal completion |
| Completion | Future terminal Rxxx status | Rewriting upstream history |

Core rule:

> **Models judge bounded semantics. The host owns identity, legality, retrieval, state transitions, hashes, schemas, execution, and durable commits.**

---

# 3. GLOBAL INVARIANTS — LOCKED

```text
G01. The raw user prompt is preserved verbatim.

G02. Stored conversation transcript is not the same thing as injected model context.

G03. Recipe 0 selects the minimum sufficient transcript evidence.

G04. Intent receives the untouched raw prompt plus the validated Conversation Packet.

G05. Intent does not query conversation history or durable SQLite knowledge directly.

G06. Accepted original Rxxx requirements are immutable for the turn.

G07. Later evidence appends resolutions, findings, revisions, discoveries, and repairs.
     It never rewrites history to pretend upstream recipes knew later information.

G08. Context may resolve a provisional Intent interpretation but does not mutate the original Intent artifact.

G09. Context semantic states such as partial, no_match, conflict, and unresolved may still be valid.

G10. Invalid / failed required Context may not enter normal Decision.

G11. Decision requires Context.ready_for_next_stage == true.

G12. Decision plans work; Execution alone establishes operation reality.

G13. A host receipt proves an execution attempt/outcome, not semantic success.

G14. Reconciliation may interpret immutable receipts but never edit them.

G15. Tool success and evidence success remain separate concepts.

G16. Downstream discovery never mutates original Intent or creates replacement Rxxx requirements.

G17. Material discovery re-enters through Context first.

G18. A downstream Context revision is not ACTIVE until its mandatory Howard promotion comment validates.

G19. The old active Context revision stays active until replacement promotion finishes successfully.

G20. Discovery and repair are separate paths.

G21. Pending, failed, superseded, and executed history is additive and never silently erased.

G22. Persistence obligations and persistence candidates are separate authority classes.

G23. SQLite semantic writes remain unavailable to Recipes 0–5.

G24. Conversation transcript storage is independent of semantic Persistence.

G25. Every durable technical artifact has a globally unique UUID identity.

G26. Human-readable IDs such as R001/W001/REC001 are scoped aliases, not database-global identities.

G27. Canonical artifact hashing uses one versioned serialization profile across all recipes.

G28. Capability registry state is snapshot-addressed and hash-addressed, not merely version-addressed.

G29. Model KV/attention state is cleared at every adapter boundary.

G30. Explicit structured artifacts are the only authoritative cross-specialist memory.
```

---

# 4. SQLITE FOUNDATION BEFORE PERSISTENCE

SQLite is used now for **technical continuity and conversation identity** without giving Recipes 0–5 semantic write authority.

The future Persistence recipe may use the same SQLite database file through a separate repository/API boundary, but its semantic tables and commit authority remain distinct.

Recommended prototype database:

```text
arcadia.sqlite3
```

Recommended startup pragmas:

```sql
PRAGMA foreign_keys = ON;
PRAGMA journal_mode = WAL;
PRAGMA synchronous = NORMAL;
PRAGMA busy_timeout = 5000;
```

## 4.1 Logical storage domains

```text
A. SYSTEM / MIGRATION METADATA
B. CONVERSATION TRANSCRIPT
C. TURN / ARTIFACT LEDGER
D. CAPABILITY REGISTRY SNAPSHOTS
E. FUTURE PERSISTENT SEMANTIC KNOWLEDGE
```

These are separate authorities even if they share one SQLite file.

## 4.2 Revision counters

Use separate monotonically increasing host-owned counters:

```text
transcript_commit_seq
ledger_commit_seq
memory_commit_seq       # reserved now; owned by future Persistence
registry_commit_seq
```

Do not use one generic revision counter as the only semantic snapshot identity.

Context persistent-memory retrieval later records `memory_commit_seq`.

Conversation Resolver history retrieval records `transcript_commit_seq`.

## 4.3 Minimum tables implemented before Recipe 0

```sql
CREATE TABLE system_meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE conversations (
    conversation_uuid TEXT PRIMARY KEY,
    created_at TEXT NOT NULL,
    status TEXT NOT NULL
);

CREATE TABLE conversation_turns (
    turn_uuid TEXT PRIMARY KEY,
    conversation_uuid TEXT NOT NULL,
    turn_index INTEGER NOT NULL,
    user_message_raw TEXT NOT NULL,
    user_message_hash TEXT NOT NULL,
    final_response TEXT,
    final_response_hash TEXT,
    status TEXT NOT NULL,
    created_at TEXT NOT NULL,
    completed_at TEXT,
    FOREIGN KEY(conversation_uuid) REFERENCES conversations(conversation_uuid),
    UNIQUE(conversation_uuid, turn_index)
);

CREATE TABLE artifacts (
    artifact_uuid TEXT PRIMARY KEY,
    turn_uuid TEXT NOT NULL,
    recipe_id TEXT NOT NULL,
    artifact_type TEXT NOT NULL,
    short_id TEXT,
    revision INTEGER NOT NULL DEFAULT 1,
    schema_version TEXT NOT NULL,
    artifact_hash TEXT NOT NULL,
    created_at TEXT NOT NULL,
    status TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    FOREIGN KEY(turn_uuid) REFERENCES conversation_turns(turn_uuid),
    UNIQUE(turn_uuid, artifact_type, short_id, revision)
);

CREATE TABLE artifact_links (
    link_uuid TEXT PRIMARY KEY,
    source_artifact_uuid TEXT NOT NULL,
    relation TEXT NOT NULL,
    target_artifact_uuid TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY(source_artifact_uuid) REFERENCES artifacts(artifact_uuid),
    FOREIGN KEY(target_artifact_uuid) REFERENCES artifacts(artifact_uuid)
);

CREATE TABLE capability_registry_snapshots (
    registry_snapshot_uuid TEXT PRIMARY KEY,
    registry_version TEXT NOT NULL,
    registry_hash TEXT NOT NULL,
    registry_commit_seq INTEGER NOT NULL,
    captured_at TEXT NOT NULL,
    payload_json TEXT NOT NULL
);
```

## 4.4 Transcript indexing

Enable SQLite FTS5 for targeted Recipe 0 history retrieval.

Conceptual table:

```sql
CREATE VIRTUAL TABLE conversation_turns_fts USING fts5(
    turn_uuid UNINDEXED,
    conversation_uuid UNINDEXED,
    user_message_raw,
    final_response,
    content=''
);
```

The host maintains this index when completed transcript turns are committed.

Recipe 0 receives only bounded candidate results chosen by the host.

## 4.5 Transcript write timing

At user-message ingress:

```text
allocate turn_uuid
insert conversation_turns row
status = OPEN
final_response = NULL
```

At successful final publication later:

```text
update same turn_uuid
final_response = exact published response
status = COMPLETED
increment transcript_commit_seq
```

Recipe 0 defaults to retrieving prior `COMPLETED` exchanges only.

Failed/open technical turns remain available to debug/ledger systems but are not normal conversational evidence unless an explicit future policy allows them.

---

# 5. PERSISTENT IDENTITY ACROSS TURNS — LOCKED FOUNDATION

There are two different identity problems.

## 5.1 Technical artifact identity — implement now

Every recipe artifact receives:

```text
artifact_uuid        globally unique UUID4 for prototype
turn_uuid            owning user turn
recipe_id            R0..R5
artifact_type        requirement/work/receipt/etc.
short_id             R001 / W001 / REC001 / ...
revision             integer
```

Rules:

```text
artifact_uuid is database identity.
short_id is human-readable trace identity.
short_id is only unique inside its owning turn/type/revision scope.
```

Never use naked `R001` as a cross-turn database key.

## 5.2 Semantic entity identity — reserve for Persistence

Future durable objects such as:

```text
person
project
preference
file identity
persistent fact
relationship
ongoing goal
```

will receive separate semantic UUIDs owned by Persistence.

Example future concept:

```text
entity_uuid: ...
entity_type: PROJECT
canonical_name: A.R.C.A.D.I.A.
```

A semantic entity may cite many transcript turns and many recipe artifacts as provenance.

A semantic entity is **not** a turn artifact.

This separation prevents `R001` or one transient Context point from accidentally becoming the permanent identity of a real-world/project concept.

---

# 6. CANONICAL HASH PROFILE — LOCKED

All Recipes 0–5 use one hash profile.

```text
profile_id: ARCADIA_CANONICAL_JSON_V1
algorithm: SHA-256
encoding: UTF-8
```

Serialization rules:

```text
1. Objects serialized with deterministic lexicographic key ordering.
2. No insignificant whitespace.
3. UTF-8, ensure_ascii = false.
4. Arrays preserve semantic order unless the schema explicitly defines the field as an unordered set.
5. null is explicit when schema requires it.
6. NaN / Infinity are forbidden.
7. Exact decimals or timestamps that matter to identity are stored as canonical strings.
8. The artifact_hash field is excluded from its own hash calculation.
9. schema_version and hash profile version are included in the hashed payload.
10. Raw and normalized representations receive separate hashes when normalization changes content.
```

Required common helpers:

```text
canonical_json_bytes(payload)
sha256_artifact(payload)
verify_artifact_hash(payload, expected_hash)
```

No recipe invents its own incompatible hashing convention.

---

# 7. COMMON ARTIFACT ENVELOPE

Where practical, all recipe artifacts use this outer host envelope:

```json
{
  "artifact_uuid": "...",
  "turn_uuid": "...",
  "recipe_id": "R2_CONTEXT",
  "artifact_type": "CONTEXT_HANDOFF",
  "short_id": null,
  "revision": 1,
  "schema_version": "prototype-1",
  "basis_refs": [],
  "payload": {},
  "validation": {},
  "created_at": "...",
  "artifact_hash": "..."
}
```

The model normally sees only the bounded payload and relevant supplied refs.

The host owns the outer envelope, UUID, timestamp, validation record, and final hash.

---

# 8. CAPABILITY REGISTRY SNAPSHOT — PATCHED FOUNDATION

Decision and Execution must not rely on a registry version string alone.

Each runtime registry capture receives:

```text
registry_snapshot_uuid
registry_version
registry_hash
registry_commit_seq
captured_at
exact capability payload
```

Decision basis carries:

```text
capability_registry_snapshot_uuid
capability_registry_version
capability_registry_hash
```

Execution requires the same snapshot identity/hash for the work graph it receives.

If runtime capability state changes before Execution and the old snapshot can no longer be honored safely:

```text
Execution does not silently substitute the new registry.
It records an explicit upstream/runtime mismatch and routes the affected work to repair/replan.
```

---

# 9. RECIPE 0 — CONVERSATION RESOLVER

## 9.1 Core question

> **What prior conversation evidence, if any, is required so Intent can interpret the current raw user prompt without inventing missing conversational references?**

Recipe 0 is not general memory retrieval.

Recipe 0 is transcript resolution only.

## 9.2 Input

Initial call receives:

```text
turn_uuid
conversation_uuid
raw_user_prompt
current transcript metadata
host policy limits
```

It does **not** receive durable semantic memory.

## 9.3 Prototype specialist allocation

Prototype uses one semantic contract:

```text
CONVERSATION RESOLVER
```

The same adapter may be reused in fresh-KV calls for two bounded modes:

```text
SCOPE_PROPOSAL
SCOPE_VALIDATION
```

This avoids allocating a second Recipe 0 adapter before field testing proves self-validation is inadequate.

If independent testing later shows systematic self-confirmation errors, split the validator into its own adapter.

## 9.4 First-pass outputs

Allowed first-pass outcomes:

```text
SUFFICIENT_WITHOUT_HISTORY
REQUEST_RECENT
REQUEST_TARGETED
```

Example:

```json
{
  "mode": "SCOPE_PROPOSAL",
  "status": "REQUEST_RECENT",
  "recent_exchange_count": 1,
  "target_terms": [],
  "reason_codes": ["UNRESOLVED_DEICTIC_REFERENCE"]
}
```

The Resolver proposes evidence scope.

The host performs retrieval.

## 9.5 Recent lookback

Recent scope is measured in **completed user/final-response exchanges**, not arbitrary message fragments.

Examples:

```text
0 exchanges
1 exchange
3 exchanges
```

The host returns them in chronological order.

On expansion, retrieve only the newly requested delta.

Do not repeatedly re-query already-frozen turns.

## 9.6 Targeted history retrieval

For explicit older references such as:

```text
remember when we decided...
earlier we said...
go back to the note-system rule...
what did I say about...
```

Resolver may request:

```text
REQUEST_TARGETED
```

with bounded search terms / quoted anchors.

The host searches `conversation_turns_fts`, applies conversation/user scope, ranks candidates, and returns bounded candidate turns with exact UUIDs and hashes.

The model never issues raw SQL.

## 9.7 Explicit "remember" rule

Words such as `remember`, `earlier`, `we decided`, `last time`, or equivalent language raise the requirement for historical resolution.

They do **not** automatically mean "load a large contiguous history window."

Rule:

> **Explicit remember language increases recall obligation, not automatic context length.**

## 9.8 Scope validation loop

After retrieval:

```text
RAW PROMPT
   +
FROZEN RETRIEVED TURN PACKET
   |
   v
CONVERSATION RESOLVER / SCOPE_VALIDATION
```

Validator asks only:

> **Can the current raw prompt now be interpreted without inventing missing conversational referents?**

Allowed verdicts:

```text
SUFFICIENT
NEEDS_MORE_RECENT
NEEDS_TARGETED_HISTORY
UNRESOLVABLE_WITH_TRANSCRIPT
BOUND_EXHAUSTED
```

If more evidence is requested, host retrieves only the additional scope and loops.

## 9.9 Prototype bounds

Freeze these as **configurable prototype defaults**, not permanent product limits:

```text
max_contiguous_lookback_exchanges = 20
max_targeted_candidate_turns_per_search = 8
max_scope_expansion_cycles = 3
max_total_injected_history_tokens = host-configured model-safe budget
```

The token limit is a hard host safety limit.

The semantic goal remains minimum sufficient context, not filling the limit.

## 9.10 Recipe 0 output packet

```text
CONVERSATION_PACKET

resolver_run_uuid
resolver_revision
turn_uuid
conversation_uuid
raw_prompt_hash
transcript_commit_seq
included_recent_turns[]
  turn_uuid
  turn_index
  content_hashes
included_targeted_turns[]
  turn_uuid
  turn_index
  content_hashes
unresolved_references[]
status
validation
packet_hash
```

## 9.11 Handoff to Intent — locked

Intent receives:

```text
EXACT RAW USER PROMPT
        +
VALIDATED CONVERSATION_PACKET
```

Recipe 0 does not rewrite the raw prompt.

Recipe 0 does not summarize prior conversation and substitute that summary for exact transcript evidence.

A bounded optional host-generated navigation/ranking note may accompany targeted results, but it is not conversation truth.

## 9.12 Failure behavior

If transcript scope cannot resolve the reference inside policy bounds:

```text
status: BOUND_EXHAUSTED
or
status: UNRESOLVABLE_WITH_TRANSCRIPT
```

Intent still receives the raw prompt plus the explicit unresolved Recipe 0 packet.

Intent must preserve the unresolved reference rather than guessing.

Context may later resolve it from durable semantic knowledge if appropriate, or downstream logic may require user clarification.

## 9.13 Recipe 0 prohibitions

Resolver does not:

```text
query durable semantic memory
query project knowledge tables
create Rxxx
rewrite user wording
execute tools
write semantic Persistence
claim a project fact
answer the user
```

---

# 10. RECIPE 1 — INTENT

Intent retains the locked five-specialist design.

## 10.1 Core question

> **What did the user communicate, and what authoritative requirement backbone should the rest of this turn preserve?**

## 10.2 Patched input

Intent now receives:

```text
raw_user_prompt
conversation_packet from Recipe 0
```

The raw prompt remains primary source text.

Conversation evidence exists to resolve conversational references, not to become a replacement prompt.

## 10.3 Specialist 1 — Spell

Input:

```text
raw prompt
```

Responsibilities:

```text
obvious spelling/punctuation/capitalization repair
preserve wording/style
flag uncertainty
```

Output:

```text
raw_prompt
normalized_prompt
spell_edits[]
uncertain_corrections[]
```

Host support:

```text
optional ftfy before Spell on detected encoding damage
difflib after Spell for edit map
```

## 10.4 Specialist 2 — Term / Meaning

Inputs:

```text
raw prompt
normalized prompt
spell uncertainties
host linguistic map
bounded Recipe 0 conversation evidence relevant to wording
```

Host support:

```text
re
regex only where earned
spaCy
```

Responsibilities:

```text
current-turn term meaning
named/project-looking terms
aliases
pronoun/reference candidates
lookup-worthy terms
confidence
```

Output remains provisional.

Recipe 0 transcript evidence may help resolve conversational antecedents; durable project/history truth remains Context's job.

## 10.5 Specialist 3 — Prompt Analyst

Core outputs:

```text
Topics
Goals
Tasks
Statements
Questions
Directions
Approvals
interaction_mode
important_claims
unresolved_items
```

It must preserve distinctions such as:

```text
request/wish != factual assertion
```

## 10.6 Specialist 4 — Intent Organizer

Receives:

```text
Meaning report
Analyst report
current capability registry summary/snapshot ref
```

Creates:

```text
primary_intent
secondary_intents
Rxxx requirements
requirement grouping/order/dependencies
context needs
capability/lane candidates
clarification status
memory candidates
unresolved blockers
```

Organizer may nominate capabilities but cannot execute them.

## 10.7 Specialist 5 — Howard Conversationalizer

Creates visible conversational Intent explanation only.

It is not downstream authority.

## 10.8 Intent immutable acceptance point — patched

After Organizer output passes host validation and the Intent artifact is accepted:

```text
intent_revision = 1
accepted = true
Rxxx backbone frozen
```

For the prototype, downstream recipes do not produce `intent_revision = 2` from discovered evidence.

If Context later determines that a provisional interpretation was wrong, it creates an explicit Context resolution referencing the original Intent item.

Original Intent remains forensic truth about what the Intent recipe initially established.

## 10.9 Intent output

Minimum handoff:

```text
turn_uuid
conversation_packet_ref/hash
intent_artifact_uuid
intent_revision = 1
intent_hash
raw_prompt
normalized_prompt
source spans Sxxx
term candidates Txxx
primary/secondary intent
Rxxx requirements
Uxxx unresolved items
capability candidates
memory candidates
interaction metadata
ready_for_context
```

## 10.10 Intent repair

Every model boundary uses schema validation and bounded repair.

Prototype default:

```text
maximum semantic-format repair attempts per model boundary = 2
```

Repair may correct malformed structure against the same exact bounded inputs.

Repair may not silently change accepted upstream facts to make validation convenient.

---

# 11. RECIPE 2 — CONTEXT

## 11.1 Core question

> **Given immutable Intent plus bounded direct input and host-retrieved persistent evidence when needed, what grounded working state should downstream recipes receive?**

SQLite read is conditional.

No SQLite retrieval is a normal pass.

## 11.2 Context input

```text
accepted Intent artifact
optional direct narrow input
optional host-selected persistent evidence lanes
```

Context does not consume a lossy replacement summary of Intent.

## 11.3 Host Context Router

Host decides:

```text
which Context lanes are required
which Split Library definition/version governs each lane
whether SQLite evidence is required
which records/candidates are retrieved
when a lane terminates
```

No router adapter.

## 11.4 Split Library

Every evidence lane has a versioned host-owned split contract specifying:

```text
purpose
allowed source kinds
allowed scopes
freshness policy
candidate maximum
whether empty result is valid
required metadata
specialist output constraints
```

Do not freeze a giant lane taxonomy.

## 11.5 SQLite evidence snapshot — patched

Context persistent-memory retrieval records:

```text
retrieved_at
memory_commit_seq
memory_snapshot_uuid if implemented
record UUIDs / durable record IDs
record timestamps
raw record content hashes
split version
intent artifact UUID/revision/hash
```

The entire lane runs against the frozen evidence packet.

A later write does not mutate already-supplied evidence.

For the prototype, row hashes remain required even when a commit sequence exists.

## 11.6 Evidence Specialist

One new Context adapter.

Core question:

> **Against this exact Context split and current Intent need, what does the supplied evidence actually support?**

Judges:

```text
relevance
support/partial support
staleness
conflict
scope applicability
remaining gaps
```

No SQL, no write, no user answer.

## 11.7 Per-lane Howard Context Commentator

Reuses the Howard conversationalization contract.

Receives validated bounded lane evidence and produces traceable Cxxx Context points.

Modes:

```text
supported
inference
unresolved
```

Every factual point has support refs.

## 11.8 Final Howard Context Synthesis

Receives explicitly:

```text
original Intent packet / bounded refs
optional direct input
all completed Context loop reports
```

Builds structured overall snapshot with:

```text
current_subject
current_job
known_context_points
resolved_references
relevant_history
current_constraints
conflicts
unresolved_items
source_refs
important_do_not_assume
```

## 11.9 Context readiness — PATCHED AND FROZEN

Normal Context validity is three-dimensional:

```text
host_valid
semantic_status
safe_for_next_stage
```

Semantic states:

```text
accepted
partial
no_match
conflict
unresolved
```

Lane statuses:

```text
completed
no_candidates
failed_validation
```

Integrated readiness rule:

```text
ready_for_next_stage = true
```

only when:

```text
all required lane artifacts are structurally/provenance valid
all requested lanes terminated honestly
no lane is in failed_validation
all required promotion transactions are settled for revisions exposed as active
all references/hashes validate
```

The following may still be `ready_for_next_stage = true`:

```text
partial
no_match
conflict
unresolved
```

because these can be honest grounded states for Decision to reason about.

A required lane with malformed/invalid unrepaired output makes overall readiness false.

## 11.10 Decision gate — patched

Decision must reject a normal run when:

```text
Context.ready_for_next_stage != true
```

Decision may not ask a model to work around an unready Context handoff.

## 11.11 Context resolution vs Intent mutation — patched

Context may "repair" a provisional Intent meaning only by appending an explicit resolution:

```text
resolution_uuid
original_intent_ref
old_provisional_value
resolved_value
support_refs
mode
```

It never rewrites the accepted Intent payload or Rxxx.

## 11.12 Downstream Context re-entry — patched

The older interface allowing downstream evidence to create an updated Intent revision is superseded.

Correct flow:

```text
REC / EF / DN / CIP
      |
      v
CONTEXT RE-ENTRY PACKET
      |
      v
rerun affected Context lane(s) only
      |
      v
new Context revision
```

Original Intent remains unchanged.

Unaffected Context lanes are preserved.

## 11.13 Promotion transaction — patched and frozen

For downstream-created/revised Context lanes:

```text
PROPOSED
   |
   v
CONTEXT_ACCEPTED
   |
   v
PROMOTION_PENDING_COMMENT
   |
   v
HOWARD CONTEXT COMMENTATOR
   |
   v
COMMENT_VALIDATED
   |
   v
ACTIVE
```

Failure path:

```text
PROMOTION_PENDING_COMMENT
   |
   +--> bounded comment repair exhausted
   |
   v
PROMOTION_COMMENT_FAILED
```

Critical transaction rule:

> The previous ACTIVE revision remains ACTIVE until the replacement revision reaches ACTIVE.

Only after the new revision is active does the host mark the prior revision `SUPERSEDED`.

This prevents a temporary gap or half-promoted Context state.

## 11.14 Context repair budget

Prototype default:

```text
maximum repair attempts per model boundary = 2
```

Comment promotion uses the same bounded Context-comment repair policy unless later testing justifies a separate constant.

---

# 12. RECIPE 3 — DECISION

## 12.1 Core question

> **Given authoritative immutable Intent requirements and active grounded Context, what work actually needs to happen next?**

## 12.2 Specialists

Exactly two:

```text
1. Requirement Assessor
2. Plan Composer
```

## 12.3 Patched upstream integrity gate

Before adapters run, host validates:

```text
turn UUID exists
Intent UUID/hash/revision valid
Context handoff UUID/hash valid
Context.ready_for_next_stage == true
all supplied active lane revisions truly ACTIVE
no PROMOTION_PENDING_COMMENT revision exposed as active
all in-scope Rxxx exist
all supplied Cxxx refs exist
capability registry snapshot UUID/hash valid
Decision scope legal
```

Failure => explicit Decision upstream failure.

No semantic adapter call.

## 12.4 Requirement Assessor

One Rxxx at a time.

Disposition vocabulary remains:

```text
READY
WORK_REQUIRED
BLOCKED
PERSISTENCE_REQUIRED
```

`READY` is nonterminal.

`PERSISTENCE_REQUIRED` is a normative remaining stage obligation, not a SQLite command.

If ordinary work is needed before persistence:

```text
disposition = WORK_REQUIRED
post_work_obligations = [PERSISTENCE]
```

## 12.5 Plan Composer

Creates smallest legitimate shared Wxxx work graph across validated assessments.

Work origins:

```text
ORIGINAL
REPAIR
DISCOVERY
```

One Wxxx may serve several Rxxx when the operation/evidence target is genuinely shared.

One Rxxx may require several Wxxx.

Dependencies are logical graph constraints.

Scheduling remains host-owned.

## 12.6 Capability snapshot — patched

Decision output stores:

```text
capability_registry_snapshot_uuid
capability_registry_version
capability_registry_hash
```

not merely the registry version.

## 12.7 Persistence obligation output — patched

Decision emits normative persistence obligations separately from ordinary Wxxx.

Conceptual normalized object:

```text
PERSISTENCE_OBLIGATION
obligation_uuid
requirement_ids
origin = DECISION
basis_refs
reason
state = PENDING
```

This object is handed forward but never executed by Tool / Execution.

## 12.8 Decision re-entry

Selective only.

Triggers include:

```text
CONTEXT_REVISION
DISCOVERY
REPAIR
DOWNSTREAM_RECONCILIATION
```

Only affected Rxxx may produce revised active Decision state/new Wxxx.

Prior Decision runs/work remain historical.

## 12.9 Decision repair budgets

```text
Requirement Assessor max repairs = 2
Plan Composer max repairs = 2
```

---

# 13. RECIPE 4 — TOOL / EXECUTION

## 13.1 Core question

> **What actually happened when the host attempted the authorized Decision work?**

## 13.2 Prototype tools

```text
Google / Search
Wiki
Load File
Save File
```

SQLite semantic persistence is not an Execution tool.

## 13.3 Dedicated adapters

```text
ZERO
```

The host compiles and validates narrow tool requests.

## 13.4 Input

Execution receives:

```text
Decision run/revision/hash
registry snapshot UUID/version/hash
active executable Wxxx graph
requirement links
Context/input refs
dependencies/parallel groups
active/superseded state
```

## 13.5 Request compilation

The host may mechanically:

```text
copy capability choice
copy query_hint into tool field
canonicalize allowed paths
populate IDs
populate attempt metadata
validate argument structure
```

It may not invent a different semantic goal.

## 13.6 Request-compilation failure — PATCHED

There are now two distinct failure points.

### A. Compiler cannot produce a meaningful TRQxxx

Example: Wxxx is semantically underspecified and there is no legal argument packet to construct.

Correct behavior:

```text
NO TRQxxx
NO RECxxx
execution_item_state:
  work_id: Wxxx
  state: REQUEST_COMPILATION_FAILED
  reason_code: INSUFFICIENT_WORK_DATA
  diagnostic refs: ...
```

This is not an operation attempt.

It routes downstream as an unexecuted-work state eligible for Reconciliation repair reasoning.

### B. TRQxxx exists but fails host schema/authority validation

Correct behavior remains:

```text
RECxxx.execution_status = REJECTED_BEFORE_EXECUTION
```

because a concrete request existed and was rejected by the host before provider invocation.

This distinction prevents fake receipts for operations that were never even compilable.

## 13.7 Pre-execution validation

Host verifies:

```text
Decision hash
Wxxx active
TRQxxx unique
Rxxx ownership
registry snapshot identity/hash
capability availability
operation kind
work/capability compatibility
argument schema
input refs
side-effect class
permissions
idempotency
dependencies
```

## 13.8 Immutable receipts

`RECxxx` is append-only operation reality.

Statuses:

```text
SUCCESS
PARTIAL
NO_RESULT
FAILED
TIMEOUT
REJECTED_BEFORE_EXECUTION
CANCELLED
```

No receipt means no claimed operation.

## 13.9 Save File

Success requires:

```text
write completed
AND post-write host verification passed
```

Ambiguous write outcomes are preserved as ambiguous/failure states, never upgraded by prose.

## 13.10 Retry policy

Prototype default:

```text
maximum automatic transport retry = 1
```

Only transient safe-to-repeat failures qualify.

Semantic insufficiency, no result, wrong page, conflict, invalid arguments, permission failure, or source disagreement are **not** transport retries.

## 13.11 Execution handoff — patched

Handoff includes both:

```text
executed_request_receipt chains
unexecuted_work_states
```

This lets Reconciliation distinguish:

```text
tool failed
request rejected
request never compilable
work superseded before execution
```

without inventing history.

---

# 14. RECIPE 5 — RECONCILIATION

## 14.1 Core question

> **Relative to the exact Wxxx evidence targets, what did the work that actually occurred establish?**

## 14.2 Specialists

Exactly two new adapters:

```text
1. Evidence Reconciler
2. Reconciliation Composer
```

Existing Howard Context Commentator is reused only when accepted downstream Context changes require promotion commentary.

## 14.3 Deterministic-first routing

Host mechanically handles cases where receipts alone conclusively establish the target.

Example:

```text
verified Save File path + expected hash + post-write verification
-> deterministic EFxxx ESTABLISHED
```

Semantic evidence sources normally require Adapter 1.

## 14.4 Evidence Finding states

```text
ESTABLISHED
PARTIAL
NOT_ESTABLISHED
CONFLICT
```

Execution status and semantic status remain independent.

## 14.5 Evidence integrity

Preserve:

```text
raw payload
raw payload hash
normalized comparison representation
normalized comparison hash
exact result refs
```

Normalization may assist comparison but never replaces raw source evidence.

## 14.6 Discovery

Material downstream discoveries create `DNxxx`.

A DNxxx:

```text
is subordinate to one or more original Rxxx
cites EF/REC provenance
is not a new user requirement
is not retroactive Intent
```

Flow:

```text
DN/CIP
  |
  v
Context re-entry
  |
  v
Context accepted
  |
  v
PROMOTION_PENDING_COMMENT
  |
  v
Howard comment validation
  |
  v
ACTIVE Context revision
  |
  v
Decision re-entry for affected Rxxx only
```

## 14.7 Repair

`RRQxxx` is used when prior planned/executed work should be corrected/replanned.

It is not used for legitimate new discovery.

Request-compilation failures from Execution may produce an RRQ path when the failure indicates Wxxx needs semantic repair.

## 14.8 Persistence relevance — patched authority split

Reconciliation may emit **advisory candidates**:

```text
PERSISTENCE_RELEVANCE_CANDIDATE
candidate_uuid
requirement_ids
source_EF_refs
source_REC_refs
suggested_action:
  CONSIDER_SAVE
  CONSIDER_UPDATE
  CONSIDER_SUPERSEDE
reason
```

These are not mandatory writes.

They remain separate from Decision's normative `PERSISTENCE_OBLIGATION` objects.

## 14.9 Discovery bounds — frozen prototype defaults

The existing Reconciliation design requires host-bounded discovery recursion. This checkpoint sets concrete prototype defaults:

```text
max_discovery_generations_per_requirement = 2
max_active_DN_per_reconciliation_run = 4
max_reconciliation_reentry_depth = 3
```

On exhaustion:

```text
DISCOVERY_BOUND_EXHAUSTED
```

is recorded honestly.

The host does not fabricate completion.

These are configuration constants and may be tuned after trace data exists.

## 14.10 Reconciliation repair

Adapter 2 Composer:

```text
initial output
-> host validation
-> one bounded repair call if invalid
-> validation
-> RECONCILIATION_REPAIR_EXHAUSTED if still invalid
```

Use a named per-stage policy constant rather than one accidental global repair number.

## 14.11 Reconciliation handoff to future Persistence

Handoff includes:

```text
validated EFxxx findings
requirement-level reconciliation posture
conflicts
DNxxx
CIPxxx
RRQxxx
Context/Decision re-entry events
normative persistence obligations carried from Decision
advisory persistence relevance candidates from Reconciliation
validation/provenance/hash
```

It does not assign terminal Completion status.

---

# 15. PERSISTENCE PREPARATION CONTRACT — NO PERSISTENCE IMPLEMENTATION YET

This checkpoint intentionally stops before implementing Recipe 6.

However, the input surface is now frozen enough to design it safely.

Future Persistence receives two authority-separated queues.

## 15.1 Normative obligations

Origin:

```text
Decision PERSISTENCE_REQUIRED
Decision post_work_obligations: PERSISTENCE
```

Conceptual shape:

```text
persistence_obligations[]
  obligation_uuid
  requirement_ids
  basis_refs
  reason
  state = PENDING
```

Persistence must resolve every in-scope normative obligation to an explicit result such as:

```text
COMMITTED
NO_CHANGE_NEEDED
REJECTED_BY_POLICY
BLOCKED
FAILED
```

It cannot silently ignore the obligation.

## 15.2 Advisory candidates

Origin:

```text
Reconciliation persistence relevance
```

Conceptual shape:

```text
persistence_candidates[]
  candidate_uuid
  requirement_ids
  evidence refs
  suggestion
  reason
```

Persistence may legitimately decide:

```text
SAVE
UPDATE
SUPERSEDE
IGNORE
DEFER
```

A candidate is never a command.

## 15.3 Conversation transcript remains separate

Persistence does not decide which normal conversation turns exist or remain in the transcript.

Transcript policy is host/runtime policy.

Normal successful conversation history stores:

```text
user raw message
final published A.R.C.A.D.I.A. response
```

Intermediate recipe artifacts belong to the durable technical ledger/debug trace, not the ordinary conversational transcript.

---

# 16. CROSS-RECIPE RE-ENTRY MATRIX

| Trigger | Re-enter | Do not re-enter by default |
|---|---|---|
| Recipe 0 insufficient recent history | Recipe 0 retrieval/validation | Intent/Context |
| Recipe 0 targeted history needed | Recipe 0 targeted retrieval | Context semantic memory |
| Intent unresolved durable/project reference | Context | Recipe 0 unless transcript ref is explicit |
| Context invalid required lane | Context repair/re-entry | Decision |
| Execution request compilation failed | Reconciliation -> possible Decision repair | Fake tool attempt |
| Tool transport transient failure | Execution retry same Wxxx | Decision |
| Tool semantic insufficiency | Reconciliation | Execution auto-retry |
| Material new term/entity from receipts | Context | Intent |
| Accepted Context discovery revision | Decision affected Rxxx only | Entire Decision graph |
| Reconciliation RRQ | Decision affected Rxxx only | Intent |
| Persistence relevance candidate | Future Persistence | Tool Execution |

---

# 17. PATCH STATUS — STRESS-TEST FAILS AND PARTIALS

## 17.1 FAIL — Invalid Context could conceptually enter Decision

**Patch:** Decision now hard-requires `ready_for_next_stage == true`.

**Status after patch:** CLOSED.

## 17.2 FAIL — Context promotion transaction ordering conflict

**Patch:** `PROPOSED -> CONTEXT_ACCEPTED -> PROMOTION_PENDING_COMMENT -> ACTIVE`; prior active revision survives until replacement activation.

**Status after patch:** CLOSED.

## 17.3 PARTIAL — Downstream discovery vs Intent revision ambiguity

**Patch:** original accepted Intent/Rxxx immutable; Context appends resolutions; downstream discovery always routes through Context and never updates Intent.

**Status after patch:** CLOSED.

## 17.4 PARTIAL — Persistent technical identity across turns

**Patch:** UUID-backed artifact/turn identity in SQLite; readable aliases are scoped only.

**Status after patch:** CLOSED FOR RECIPES 0–5. Semantic entity identity reserved for Persistence.

## 17.5 PARTIAL — SQLite snapshot coherence once Persistence begins writing

**Patch:** separate `memory_commit_seq`; Context evidence captures commit sequence + row hashes + retrieval timestamp.

**Status after patch:** INTERFACE CLOSED; Persistence must implement commit sequencing transactionally.

## 17.6 PARTIAL — Persistence required vs persistence suggested

**Patch:** normative `persistence_obligations[]` separated from advisory `persistence_candidates[]`.

**Status after patch:** CLOSED.

## 17.7 PARTIAL — Capability registry version insufficient

**Patch:** registry snapshot UUID + hash + version travel through Decision/Execution.

**Status after patch:** CLOSED.

## 17.8 PARTIAL — Request compilation had no exact historical representation

**Patch:** `REQUEST_COMPILATION_FAILED` unexecuted-work state; no fake TRQ/REC.

**Status after patch:** CLOSED.

## 17.9 PARTIAL — Discovery bounds existed without prototype values

**Patch:** defaults set to `2 generations / 4 active DN / depth 3`.

**Status after patch:** CLOSED FOR PROTOTYPE, tunable later.

## 17.10 PARTIAL — "Persistent turn ledger" naming collision with semantic Persistence

**Patch:** integrated implementation terminology becomes:

```text
TURN LEDGER / RECIPE TRACE
```

The source Intent phrase may remain historically in its original spec, but new code/docs should avoid calling the technical ledger "persistent memory."

**Status after patch:** CLOSED.

---

# 18. INTEGRATED PROTOTYPE SOURCE LAYOUT

Recommended integration tree:

```text
arcadia/
|
+-- core/
|   +-- config.py
|   +-- ids.py
|   +-- canonical_json.py
|   +-- hashing.py
|   +-- time.py
|   +-- schemas.py
|   +-- artifact_envelope.py
|   +-- sqlite_store.py
|   +-- migrations.py
|   +-- ledger.py
|   +-- transcript.py
|   +-- registry.py
|   +-- validation.py
|   +-- repair_policy.py
|   +-- adapter_runtime.py
|   +-- kv_control.py
|   +-- trace.py
|
+-- recipes/
|   +-- r0_conversation_resolver/
|   |   +-- controller.py
|   |   +-- resolver_runner.py
|   |   +-- transcript_retrieval.py
|   |   +-- schemas/
|   |
|   +-- r1_intent/
|   |   +-- controller.py
|   |   +-- spell_runner.py
|   |   +-- meaning_runner.py
|   |   +-- analyst_runner.py
|   |   +-- organizer_runner.py
|   |   +-- howard_runner.py
|   |   +-- linguistic_support.py
|   |   +-- schemas/
|   |
|   +-- r2_context/
|   |   +-- controller.py
|   |   +-- router.py
|   |   +-- split_library.py
|   |   +-- evidence_retrieval.py
|   |   +-- evidence_runner.py
|   |   +-- howard_comment_runner.py
|   |   +-- synthesis.py
|   |   +-- promotion.py
|   |   +-- schemas/
|   |
|   +-- r3_decision/
|   |   +-- controller.py
|   |   +-- assessor_runner.py
|   |   +-- composer_runner.py
|   |   +-- graph_validation.py
|   |   +-- persistence_obligations.py
|   |   +-- schemas/
|   |
|   +-- r4_execution/
|   |   +-- controller.py
|   |   +-- request_compiler.py
|   |   +-- scheduler.py
|   |   +-- receipts.py
|   |   +-- retry.py
|   |   +-- tools/
|   |   |   +-- google_search.py
|   |   |   +-- wiki_lookup.py
|   |   |   +-- load_file.py
|   |   |   +-- save_file.py
|   |   +-- schemas/
|   |
|   +-- r5_reconciliation/
|       +-- controller.py
|       +-- evidence_bundle.py
|       +-- normalization.py
|       +-- signal_pack.py
|       +-- evidence_runner.py
|       +-- composer_runner.py
|       +-- discovery.py
|       +-- repair.py
|       +-- reentry.py
|       +-- persistence_candidates.py
|       +-- schemas/
|
+-- storage/
|   +-- migrations/
|   |   +-- 0001_core_identity.sql
|   |   +-- 0002_transcript.sql
|   |   +-- 0003_artifact_ledger.sql
|   |   +-- 0004_registry_snapshots.sql
|   +-- arcadia.sqlite3        # runtime-generated, not source-controlled
|
+-- fixtures/
|   +-- capability_registry.prototype.json
|   +-- split_library.prototype.json
|
+-- tests/
    +-- core/
    +-- r0/
    +-- r1/
    +-- r2/
    +-- r3/
    +-- r4/
    +-- r5/
    +-- integration/
```

Keep model runners thin.

Keep host logic independently unit-testable.

---

# 19. EXACT PROTOTYPE BUILD ORDER

This is the recommended implementation order from an empty integration branch.

Do not wire later recipes before the upstream contract tests listed at each gate pass.

## PHASE A — Shared host foundation

### A01 — Repository skeleton
Create the integrated source tree from Section 18.

### A02 — Configuration constants
Add one versioned config source for:

```text
repair budgets
Recipe 0 bounds
Reconciliation discovery bounds
timeouts
transport retry limit
candidate limits
schema versions
hash profile
```

### A03 — SQLite connection layer
Implement WAL, foreign keys, busy timeout, transaction helper, rollback behavior.

### A04 — Migration runner
Implement ordered migration application and schema-version recording.

### A05 — Core identity migration
Create `system_meta`, `conversations`, `conversation_turns`, `artifacts`, `artifact_links`, registry snapshot tables.

### A06 — UUID service
Use host-generated UUID4 for prototype.

Test uniqueness and no model-owned canonical IDs.

### A07 — Canonical JSON V1
Implement deterministic serializer.

### A08 — Hashing service
Implement artifact hash generation/verification and raw-vs-normalized hash support.

### A09 — Artifact envelope
Implement common host envelope and schema-version field.

### A10 — Ledger repository
Append/read artifacts by UUID, turn, type, alias, revision.

### A11 — Conversation transcript repository
Implement OPEN/COMPLETED turn lifecycle.

### A12 — FTS5 transcript index
Implement indexing/rebuild/search limited to authorized conversation scope.

### A13 — Commit sequence service
Implement transcript/ledger/registry counters; reserve memory counter.

### A14 — Capability registry snapshot service
Capture exact registry payload, UUID, version, hash, commit sequence.

### A15 — JSONSchema gate library
Central parse/schema error representation.

### A16 — Repair-policy library
Named per-stage repair constants; no accidental global one-size limit.

### A17 — Adapter runtime abstraction
Load/switch adapters, clear KV, capture adapter/base identity/hash, call metrics.

### A18 — Trace/debug writer
Capture exact explicit inputs/outputs/validation without requiring hidden chain-of-thought.

### A19 — Foundation test gate
Must pass:

```text
UUID uniqueness
canonical hash reproducibility
hash tamper detection
SQLite rollback
commit-seq monotonicity
transcript status lifecycle
FTS5 scoped retrieval
artifact foreign-key integrity
registry snapshot hash stability
KV clear hook invocation
```

**Do not build Recipe 0 until A19 passes.**

---

## PHASE B — Recipe 0 Conversation Resolver

### B01 — Define Recipe 0 schemas

```text
scope_proposal.schema.json
scope_validation.schema.json
conversation_packet.schema.json
```

### B02 — Host initial resolver packet builder
Raw prompt + current conversation metadata + bounds only.

### B03 — Resolver SCOPE_PROPOSAL runner
Implement fresh-KV call and host schema gate.

### B04 — Zero-history fast completion
If resolver returns `SUFFICIENT_WITHOUT_HISTORY`, build validated empty-history packet and stop.

### B05 — Recent transcript retrieval
Retrieve exact completed exchanges by turn UUID/index, frozen with content hashes.

### B06 — Targeted FTS5 retrieval
Use resolver-proposed bounded terms; return candidate turns only.

### B07 — Scope validation runner
Fresh KV. Raw prompt + frozen retrieved turns.

### B08 — Incremental expansion loop
Retrieve only delta turns/candidates requested by validator.

### B09 — Bound enforcement
Implement lookback/candidate/cycle/token ceilings and `BOUND_EXHAUSTED`.

### B10 — Recipe 0 artifact/ledger write
Append proposal, retrieval refs, validations, packet.

### B11 — Recipe 0 independent tests
At minimum:

```text
self-contained prompt -> 0 history
"do that" -> 1 sufficient exchange
three-turn reference -> exactly enough contiguous turns
explicit remember -> targeted retrieval
first pass insufficient -> incremental expansion
unresolvable transcript ref -> explicit unresolved
bound exhaustion -> no guessing
retrieved turn hash tamper -> fail
open/failed turns excluded by default
raw prompt unchanged in handoff
```

### B12 — Freeze R0 -> Intent handoff

**Do not integrate Intent until B11 passes.**

---

## PHASE C — Recipe 1 Intent

### C01 — Patch Intent input schema
Add Conversation Packet ref/hash.

### C02 — Spell schema + runner

### C03 — Spell host validation/repair

### C04 — Deterministic spelling support
ftfy gating + difflib edit map.

### C05 — Meaning host linguistic map
re/spaCy/optional regex.

### C06 — Meaning schema + runner
Pass only bounded relevant Recipe 0 transcript evidence.

### C07 — Meaning validation/repair

### C08 — Prompt Analyst schema + runner

### C09 — Analyst validation/repair

### C10 — Capability snapshot projection for Organizer
Compact current capability knowledge with snapshot ref/hash.

### C11 — Intent Organizer schema + runner

### C12 — Rxxx allocation service
Host allocates authoritative requirement IDs.

### C13 — Organizer validation/repair

### C14 — Intent acceptance/freeze
After accepted Organizer:

```text
intent_revision = 1
Rxxx immutable
```

### C15 — Howard Intent Conversationalizer
Visible prose only.

### C16 — Final Intent handoff
Include R0 packet ref/hash.

### C17 — Intent tests

```text
spelling repair without meaning drift
wish vs assertion
multi-requirement decomposition
ambiguous history preserved when R0 unresolved
capability candidate without execution
no SQLite access
no conversation archive search
Rxxx immutable after acceptance
visible Howard prose not downstream authority
```

### C18 — Freeze Intent -> Context contract

---

## PHASE D — Recipe 2 Context

### D01 — Context dataclasses/internal models

### D02 — Context input/handoff schemas

### D03 — Split Library loader/version validator

### D04 — Host Context Router

### D05 — No-SQLite path
Must work before retrieval lanes exist.

### D06 — Persistent evidence repository read interface
Read-only API only. No raw SQL exposed to models.

### D07 — Frozen evidence snapshot builder
Capture memory commit seq + rows/hashes/timestamp.

### D08 — Pre-loop host validator

### D09 — Empty/no-candidate deterministic lane termination

### D10 — Evidence Specialist schema + runner

### D11 — Evidence validation/repair
Max 2.

### D12 — Howard per-lane Context Commentator

### D13 — Howard comment validation/repair

### D14 — Context loop report

### D15 — Final Howard Context Synthesis

### D16 — Final Context host validator

### D17 — Implement patched readiness policy
Invalid required lane => false; valid partial/no_match/conflict/unresolved may remain true.

### D18 — Context resolution artifact
Resolve provisional Intent refs without mutating Intent.

### D19 — Context revision model
Active/superseded revision tracking.

### D20 — Promotion transaction state machine

```text
PROPOSED
CONTEXT_ACCEPTED
PROMOTION_PENDING_COMMENT
ACTIVE
PROMOTION_COMMENT_FAILED
SUPERSEDED
```

### D21 — Atomic promotion behavior
Old ACTIVE stays active until new ACTIVE.

### D22 — Selective Context re-entry interface
Accept DN/CIP packets later; never Intent revisions.

### D23 — Context tests

```text
no-SQLite pass
valid empty lane
accepted evidence
partial
conflict preserved
unresolved preserved
stale evidence
phantom evidence ref rejection
frozen snapshot consistency
Intent hash preserved
Context resolution appended, not mutated
failed required lane -> ready false
partial valid lane -> ready true
promotion comment failure -> old revision remains active
new revision not visible while PROMOTION_PENDING_COMMENT
selective lane re-entry
```

### D24 — Freeze Context -> Decision contract

---

## PHASE E — Recipe 3 Decision

### E01 — Decision dataclasses/models

### E02 — Requirement Assessor schemas

### E03 — Patched upstream integrity validator
Explicit Context readiness + registry snapshot hash.

### E04 — Assessor runner

### E05 — Assessor validation/repair
Max 2.

### E06 — Assessor fixture suite

### E07 — Work item + handoff schemas

### E08 — Work ID allocation

### E09 — Plan Composer runner

### E10 — Requirement coverage validator

### E11 — Capability snapshot compatibility validator

### E12 — Dependency graph validator

### E13 — Side-effect authority validator

### E14 — Composer validation/repair
Max 2.

### E15 — Persistence obligation normalizer
Create normative objects outside normal Tool Wxxx.

### E16 — Decision ledger append

### E17 — Scoped Decision re-entry

### E18 — DN/CIP input interface
Context must already have accepted/promoted the relevant revision.

### E19 — RRQ repair input interface

### E20 — Decision tests

```text
ready no-work
work required
blocked missing context
Context ready=false rejected before model
PERSISTENCE_REQUIRED no SQLite operation
work + post persistence obligation
registry hash mismatch
shared work merge
multiple W for one R
cycle rejection
unknown capability rejection
side-effect mismatch
selective re-entry
Rxxx unchanged
```

### E21 — Freeze Decision -> Execution contract

---

## PHASE F — Recipe 4 Tool / Execution

### F01 — Execution dataclasses/models

### F02 — Request/receipt schemas

### F03 — Request compiler common envelope

### F04 — Implement REQUEST_COMPILATION_FAILED state
No TRQ/REC.

### F05 — Google request compiler/executor

### F06 — Wiki request compiler/executor

### F07 — Load File request compiler/executor

### F08 — Save File request compiler/executor

### F09 — Registry snapshot exact-match gate

### F10 — Permission/path/side-effect gates

### F11 — Dependency scheduler

### F12 — Parallel group scheduler

### F13 — Receipt builder/hashing

### F14 — Tool-specific normalization

### F15 — Save File post-write verification

### F16 — Idempotency support

### F17 — Transport retry policy
Max automatic retry 1.

### F18 — Cancellation/timeouts

### F19 — Execution handoff builder
Include receipts + unexecuted work states.

### F20 — Execution tests

```text
Google success
Google no-result
Wiki ambiguous page
Load File success but irrelevant contents retained
Save File verified success
Save File permission rejection
Save File ambiguous timeout/idempotency
request compiler underspecified -> no TRQ/REC
compiled request invalid -> REJECTED_BEFORE_EXECUTION receipt
registry snapshot mismatch
superseded-before-execution
single transient retry
semantic insufficiency not retried
parallel receipts remain separate
receipt immutability
```

### F21 — Freeze Execution -> Reconciliation contract

---

## PHASE G — Recipe 5 Reconciliation

### G01 — Reconciliation dataclasses/namespaces

### G02 — Input/handoff schemas including unexecuted work state

### G03 — Upstream integrity validator

### G04 — Receipt/work evidence grouping

### G05 — Raw + normalized evidence representation

### G06 — ftfy/Unicode normalization preserving raw evidence

### G07 — Exact duplicate hashes

### G08 — RapidFuzz bounded similarity signals

### G09 — spaCy linguistic signals

### G10 — Evidence Signal Pack schema

### G11 — Deterministic receipt reconciliation path

### G12 — Evidence Reconciler schemas

### G13 — Adapter 1 runner

### G14 — Adapter 1 validation/repair
Use the locked Reconciliation boundary policy.

### G15 — Evidence Reconciler fixture suite

### G16 — Composer schemas

### G17 — DN schema

### G18 — CIP schema

### G19 — RRQ schema

### G20 — Persistence relevance candidate schema

### G21 — Adapter 2 runner

### G22 — Adapter 2 validation + one repair

### G23 — Discovery -> Context router

### G24 — Selective Context scope calculation

### G25 — Context promotion event interface

### G26 — Howard Context Commentator reuse wiring

### G27 — Decision discovery re-entry interface

### G28 — Decision repair re-entry interface

### G29 — Request-compilation-failure reconciliation path

### G30 — Persistence obligation carry-forward

### G31 — Persistence candidate generation

### G32 — Discovery counters/limits

### G33 — Additive ledger append

### G34 — Final Reconciliation handoff

### G35 — Reconciliation tests

```text
execution success + evidence established
execution success + evidence not established
partial evidence
conflicting sources
exact duplicate evidence
near duplicate signal only
material term -> DN
incidental term -> no DN
DN never mutates Intent
Context re-entry mandatory
Context rejects discovery
promotion comment required
promotion comment failure keeps old Context active
repair vs discovery distinction
request-compilation failure -> repair candidate path
persistence candidate no SQLite write
normative obligation preserved separately
save-file deterministic path
bound exhaustion
selective re-entry
no terminal Rxxx status
```

### G36 — Freeze R5 -> Persistence input contract

---

## PHASE H — Six-slice integration tests

### H01 — Zero-history direct-answer turn

```text
R0 -> 0 history
Intent -> direct conversational requirement
Context -> no SQLite
Decision -> READY
Execution -> zero work
Reconciliation -> no further action
```

### H02 — One-turn pronoun/continuation
Recipe 0 retrieves exactly one prior exchange; Intent correctly resolves conversational reference.

### H03 — Recipe 0 expansion
First retrieval insufficient; second delta resolves reference; no unnecessary older turns injected.

### H04 — Targeted old-history recall
FTS5 retrieves specific old turn rather than loading all intervening conversation.

### H05 — Durable project-state lookup
Recipe 0 does not search semantic memory; Intent marks context need; Context retrieves persistent evidence.

### H06 — Search success / semantic failure
Execution SUCCESS, Reconciliation NOT_ESTABLISHED.

### H07 — Discovery loop

```text
R001
-> W001
-> REC001
-> EF001
-> DN001
-> Context revision
-> Howard promotion comment
-> ACTIVE
-> Decision re-entry
-> W002
```

R001 remains unchanged.

### H08 — Context comment failure
New revision never becomes active; prior active revision survives.

### H09 — Decision refuses unready Context
No adapter call.

### H10 — Request compiler failure
No TRQ/REC; Reconciliation can propose repair.

### H11 — Save File verified success
Receipt proves operation; deterministic EF; no unnecessary semantic adapter.

### H12 — Persistence obligation vs candidate
One Rxxx produces mandatory persistence obligation while another evidence finding only produces advisory candidate; handoff keeps them separate.

### H13 — Registry hot-change
Decision planned on snapshot A; live registry becomes B; Execution does not silently substitute B.

### H14 — SQLite concurrent write snapshot
Context lane keeps frozen `memory_commit_seq` + row hashes even if memory changes afterward.

### H15 — Full provenance replay
Given stored transcript/ledger artifacts, reconstruct every explicit recipe input/output/hash without hidden KV state.

### H16 — Six-slice stress suite gate
All failures must be explicit; no fabricated clean handoff.

**Only after H16 passes should Persistence implementation begin.**

---

# 20. REQUIRED PROTOTYPE TEST NAMES

Recommended stable test identifiers:

```text
test_core_uuid_global_identity
test_core_short_ids_scoped
test_core_canonical_hash_reproducible
test_core_hash_tamper_detected
test_core_sqlite_commit_sequences
test_core_registry_snapshot_hash

test_r0_zero_history
test_r0_one_turn_reference
test_r0_incremental_expand
test_r0_targeted_history
test_r0_explicit_remember_not_unbounded
test_r0_bound_exhaustion
test_r0_raw_prompt_unchanged

test_intent_spell_preserves_meaning
test_intent_wish_not_assertion
test_intent_requirement_identity
test_intent_no_sqlite
test_intent_no_archive_search
test_intent_accepted_rxxx_immutable

test_context_no_sqlite_path
test_context_frozen_evidence_snapshot
test_context_conflict_valid
test_context_unresolved_valid
test_context_failed_lane_not_ready
test_context_resolution_does_not_mutate_intent
test_context_promotion_pending_not_active
test_context_old_revision_survives_comment_failure

test_decision_requires_context_ready
test_decision_registry_snapshot_integrity
test_decision_persistence_required_not_tool
test_decision_shared_work_merge
test_decision_dependency_cycle_rejected
test_decision_selective_reentry

test_execution_request_compilation_failed_no_receipt
test_execution_rejected_request_receipt
test_execution_receipt_immutable
test_execution_save_file_verified
test_execution_transport_retry_one
test_execution_semantic_failure_not_retry
test_execution_registry_snapshot_mismatch

test_reconciliation_execution_vs_semantic_status
test_reconciliation_raw_evidence_preserved
test_reconciliation_duplicate_signal
test_reconciliation_discovery_not_intent
test_reconciliation_discovery_requires_context
test_reconciliation_repair_not_discovery
test_reconciliation_persistence_candidate_advisory
test_reconciliation_obligation_preserved
test_reconciliation_discovery_bounds

test_integration_minimum_history
test_integration_targeted_history
test_integration_context_to_decision_gate
test_integration_discovery_loop
test_integration_promotion_atomicity
test_integration_request_compilation_repair
test_integration_registry_change
test_integration_full_replay
```

---

# 21. PERFORMANCE / EFFECTIVENESS RULES

Optimization is subordinate to authority correctness, but the architecture deliberately avoids waste.

```text
1. Recipe 0 injects minimum sufficient transcript, not fixed maximum history.
2. Targeted retrieval avoids walking backward through irrelevant turns.
3. Empty deterministic paths skip model calls where possible.
4. Context does not query SQLite when Intent + conversation already provide enough state.
5. Context empty-result lanes may terminate without a semantic model call.
6. Decision assesses one Rxxx at a time before cross-requirement composition.
7. Execution uses zero dedicated adapters.
8. Reconciliation bypasses semantic adapters for mechanically sufficient receipts.
9. Re-entry is selective, not full-pipeline replay.
10. KV state is cleared; adapters may remain loaded/warm.
11. Raw evidence is stored once and referenced by identity/hash instead of repeatedly copied where runtime allows.
12. Host validators catch mechanical faults before expensive model repair.
```

The optimization target is:

> **smallest sufficient context + narrowest sufficient model call + strongest deterministic host gate.**

---

# 22. ADAPTER CONTRACT COUNT AT THIS CHECKPOINT

Unique learned roles before Persistence:

```text
Recipe 0
  Conversation Resolver                         1

Intent
  Spell                                         1
  Term / Meaning                                1
  Prompt Analyst                                1
  Intent Organizer                              1
  Howard Conversationalizer                     1

Context
  Evidence Specialist                           1
  Howard role reused                            0 new

Decision
  Requirement Assessor                          1
  Plan Composer                                 1

Execution
  dedicated adapters                            0

Reconciliation
  Evidence Reconciler                           1
  Reconciliation Composer                       1
  Howard Context Commentator reused             0 new
```

Total unique learned contracts if Conversation Resolver receives its own adapter:

```text
11
```

Do not merge semantically distinct jobs merely to reduce this number.

If runtime residency limits require fewer simultaneously loaded adapters, handle that through adapter loading/eviction policy rather than corrupting recipe ownership.

---

# 23. WHAT IS STORED AFTER A COMPLETED TURN

Three separate retention classes remain.

## 23.1 Conversation transcript

```text
exact user message
exact final published response
```

Used by Recipe 0 in future turns.

## 23.2 Technical turn ledger / debug trace

```text
Recipe 0 requests/retrievals/validation
Intent specialist artifacts
Context evidence/lanes/comments/snapshot
Decision assessments/work graph
TRQ/REC or unexecuted work state
Reconciliation findings/discoveries/repairs
validation/repair events
hashes/timings/model identities
```

Used for provenance, debugging, replay, evaluation, and deliberate training-data extraction.

It is not ordinary conversational context.

## 23.3 Future persistent semantic knowledge

Only future Persistence-approved durable state.

It is neither the transcript nor the technical ledger.

---

# 24. PERSISTENCE DESIGN ENTRY CHECKLIST

Do not draft implementation details for Persistence until the following are true:

```text
[ ] Recipe 0 contract implemented/tested.
[ ] Intent accepts Conversation Packet + raw prompt.
[ ] Intent Rxxx immutable after acceptance.
[ ] Context resolution replaces old Intent-revision reentry wording.
[ ] Context readiness policy is deterministic and tested.
[ ] Decision rejects Context ready=false.
[ ] Context promotion transaction is atomic.
[ ] Registry snapshot UUID/hash travels Decision -> Execution.
[ ] Request compilation failure has non-receipt representation.
[ ] Reconciliation accepts unexecuted-work state.
[ ] Discovery limits are configured.
[ ] Normative persistence obligations are separate objects.
[ ] Advisory persistence candidates are separate objects.
[ ] UUID technical identity is stored in SQLite.
[ ] Transcript and ledger tables are operational.
[ ] memory_commit_seq interface is reserved.
[ ] canonical JSON/hash profile is common across recipes.
[ ] six-slice integration stress suite passes.
```

When these are satisfied, Persistence receives a stable upstream contract rather than being forced to repair ambiguity in earlier recipes.

---

# 25. FINAL PRE-PERSISTENCE FLOW — AUTHORITATIVE CHECKPOINT

```text
USER MESSAGE ARRIVES
      |
      +--> Host allocates turn_uuid
      +--> transcript row OPEN
      |
      v
RECIPE 0 — CONVERSATION RESOLVER
      |
      | raw prompt inspected
      | minimum history requested
      | host retrieves exact transcript turns
      | validator may request incremental expansion
      | frozen Conversation Packet
      v
RAW PROMPT + CONVERSATION PACKET
      |
      v
RECIPE 1 — INTENT
      |
      | Spell
      | Meaning
      | Analyst
      | Organizer
      | Rxxx accepted/frozen
      | Howard visible Intent
      v
IMMUTABLE INTENT HANDOFF
      |
      v
RECIPE 2 — CONTEXT
      |
      | host routes required lanes
      | optional frozen SQLite evidence
      | Evidence Specialist
      | Howard Context points
      | final Context synthesis
      | host validation
      | ready_for_next_stage
      v
VALIDATED ACTIVE CONTEXT
      |
      v
RECIPE 3 — DECISION
      |
      | hard Context readiness gate
      | Requirement Assessor
      | Plan Composer
      | Wxxx graph
      | normative persistence obligations separated
      v
VALIDATED WORK GRAPH
      |
      v
RECIPE 4 — TOOL / EXECUTION
      |
      | host request compilation
      | if not compilable -> explicit unexecuted state
      | otherwise TRQxxx
      | host execution
      | immutable RECxxx
      v
EXECUTION HANDOFF
      |
      v
RECIPE 5 — RECONCILIATION
      |
      | deterministic-first
      | EFxxx semantic findings
      | conflict preservation
      | DN/CIP discovery if material
      | RRQ repair if prior work needs correction
      | advisory persistence candidates
      |
      +--> Context re-entry when discovery changes grounding
      |       |
      |       +--> PROMOTION_PENDING_COMMENT
      |       +--> validated Howard comment
      |       +--> ACTIVE
      |       +--> Decision selective re-entry
      |       +--> Execution
      |       +--> Reconciliation
      |
      v
VALIDATED PRE-PERSISTENCE HANDOFF
      |
      +--> normative persistence obligations[]
      +--> advisory persistence candidates[]
      +--> immutable provenance graph
      |
      v
RECIPE 6 — PERSISTENCE
      [NEXT DESIGN]
```

---

# 26. FINAL LOCKED PRINCIPLES

```text
Stored != injected.

Transcript != semantic memory.

Technical artifact identity != semantic entity identity.

Conversation resolution != Intent.

Context resolution != Intent mutation.

Valid unresolved state != failure.

Invalid Context != Decision input.

Planned work != executed work.

Execution success != semantic success.

Discovery != repair.

Discovery != new Intent.

Persistence obligation != persistence suggestion.

Receipt != claim of truth.

Howard commentary != host authority.

Human-readable IDs != global database identity.

Previous active Context remains active until replacement promotion is complete.

Every loop is bounded.

Every re-entry is scoped.

Every durable artifact is traceable.

Every semantic write waits for Persistence.
```

---

# 27. CHECKPOINT STATUS

**Recipe 0 — Conversation Resolver:** DESIGN FROZEN BY THIS CHECKPOINT  
**Recipe 1 — Intent:** RETAINED + PATCHED INPUT/IMMUTABILITY CONTRACT  
**Recipe 2 — Context:** RETAINED + PATCHED REENTRY/READINESS/PROMOTION/SNAPSHOT CONTRACTS  
**Recipe 3 — Decision:** RETAINED + PATCHED CONTEXT GATE/REGISTRY/PERSISTENCE OBLIGATION CONTRACTS  
**Recipe 4 — Tool / Execution:** RETAINED + PATCHED REQUEST-COMPILATION/REGISTRY CONTRACTS  
**Recipe 5 — Reconciliation:** RETAINED + PATCHED BOUNDS/PERSISTENCE-SEPARATION/UNEXECUTED-WORK INTERFACE  
**Recipe 6 — Persistence:** NOT YET DESIGNED; UPSTREAM ENTRY CONTRACT NOW PREPARED  

**GO / NO-GO:** **GO to prototype implementation of Recipes 0–5 under this checkpoint. Persistence design begins after the six-slice integration gate passes.**

**END OF A.R.C.A.D.I.A. FULL PROJECT CHECKPOINT — PRE-PERSISTENCE — 2026-08-28**
