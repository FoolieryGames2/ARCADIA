# A.R.C.A.D.I.A. — Persistence Entry Patch
## Delta against `ARCADIA_FULL_PROJECT_CHECKPOINT_PRE_PERSISTENCE_2026-08-28.md`
**Date:** 2026-08-28  
**Purpose:** Record only the upstream interface changes required by the locked Recipe 6 Persistence design. The parent checkpoint remains the source for Recipes 0–5 except where this patch explicitly extends the Persistence handoff.

# P6-01 — Context-origin advisory persistence candidates

The parent checkpoint already allows Intent to carry memory candidates but its frozen Persistence preparation contract only names Reconciliation as the advisory candidate origin.

Recipe 6 adds the missing ordinary-user-state path:

```text
Intent memory candidate
      |
      v
Context grounding
      |
      v
CONTEXT_PERSISTENCE_CANDIDATE
authority = ADVISORY
      |
      v
Persistence
```

Context may emit this candidate only when it can cite the user-origin assertion and its accepted grounded Context refs.

Context still cannot write SQLite.

# P6-02 — Persistence receives three logical sources

The Recipe 6 input surface is:

```text
1. Decision normative persistence obligations[]
2. Context advisory persistence candidates[]
3. Reconciliation advisory persistence candidates[]
```

Authority remains:

```text
Decision obligation = MUST RESOLVE EXPLICITLY
Context candidate = MAY SAVE / IGNORE / DEFER
Reconciliation candidate = MAY SAVE / IGNORE / DEFER
```

# P6-03 — Semantic read repository after Persistence exists

Context may retrieve durable semantic state only through:

```text
SemanticMemoryReadRepository
```

and records:

```text
memory_snapshot_uuid
memory_commit_seq
record hashes
retrieved_at
```

Context receives no semantic write repository.

Recipe 0 remains transcript-only and receives no semantic-memory repository.

# P6-04 — Semantic identity namespaces

Add durable semantic namespaces:

```text
E000001  Entity convenience ID
M000001  Claim convenience ID
CF000001 Conflict convenience ID
```

Global UUID remains authoritative identity.

These semantic IDs are not scoped recipe artifact IDs and do not replace `artifact_uuid`.

# P6-05 — Persistence trace artifacts

Recipe 6 adds technical ledger artifacts:

```text
PA001   Persistence Assessment
PP001   Persistence Plan
PRC001  Persistence Commit Receipt
```

These remain turn artifacts and are separate from semantic E/M/CF identities.

# P6-06 — Learned contract count

Recipe 6 adds exactly:

```text
Persistence Assessor
Persistence Composer
```

No SQL/tool adapter is added.

Relative to the parent checkpoint's 11 unique learned contracts, the full Recipe 0–6 prototype therefore has:

```text
13 unique learned contracts
```

# P6-07 — Completion boundary

Persistence handoff carries obligation/candidate results plus immutable commit evidence.

Persistence still does not assign terminal Rxxx status.

Recipe 7 Completion remains the first stage allowed to do that.

**END PATCH**
