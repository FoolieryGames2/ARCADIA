---
title: "A.R.C.A.D.I.A. v0.1 — Recipe 0 Conversation Resolver"
project: "A.R.C.A.D.I.A."
version: "0.1-prototype"
checkpoint_date: "2026-08-29"
document_role: "recipe-contract"
source_path: "recipes/R0_CONVERSATION_RESOLVER_V0_1.md"
source_sha256: "68dc722f911aba8cad57125ccfbf80c89b8f9ff1a535a02b2232f4d913623bfb"
source_bytes: 6602
source_integrity: "updated-2026-09-03-continuation-fix"
tags:
  - "arcadia/v0-1"
  - "type/recipe"
  - "status/frozen"
aliases:
  - "R0_CONVERSATION_RESOLVER_V0_1.md"
  - "A.R.C.A.D.I.A. v0.1 — Recipe 0 Conversation Resolver"
---

> [!info] Obsidian navigation
> **Checkpoint role:** `recipe-contract`  
> **Frozen source:** `recipes/R0_CONVERSATION_RESOLVER_V0_1.md` · SHA-256 `f6361279aa8b3ff4…`  
> **Command center:** [[ARCADIA v0.1 - Command Center]]  
> **Connected:** [[01_ARCADIA_V0_1_FULL_PROJECT_CHECKPOINT]] · [[03_ARCADIA_V0_1_GLOBAL_CONTRACTS_AND_INVARIANTS]] · [[04_ARCADIA_V0_1_AAE_CONTRACT_REGISTRY_AND_SERIALIZATION]] · [[R1_INTENT_V0_1]]

<!-- OBSIDIAN_LAYER_END — ORIGINAL SOURCE CONTENT BEGINS BELOW -->

# A.R.C.A.D.I.A. v0.1 — Recipe 0 Conversation Resolver

**Question:** What prior conversation evidence, if any, is required so Intent can interpret the current raw user prompt without inventing missing conversational references?

# 1. Scope

Recipe 0 is transcript resolution only. It does not query durable semantic memory, create Intent requirements, execute tools, or answer the user.

# 2. Input

```text
turn_uuid
conversation_uuid
raw_user_prompt
transcript metadata
host policy bounds
```

# 3. Learned allocation

One physical `Conversation Resolver` adapter may expose independently qualified modes:

```text
SCOPE_PROPOSAL
SCOPE_VALIDATION
```

Every attempt uses the shared SpecialistInvoker/AAE/InferenceProfile boundary.

# 4. Proposal outcomes

```text
SUFFICIENT_WITHOUT_HISTORY
REQUEST_RECENT
REQUEST_TARGETED
```

Recent scope is measured in completed user/final-response exchanges. Explicit “remember/earlier/we decided” language increases the obligation to resolve history but does not automatically justify a large contiguous window.

# 5. Host retrieval

- recent exchange retrieval is chronological;
- expansion retrieves only the delta;
- targeted lookup uses transcript FTS within authorized conversation/user scope;
- model never emits raw SQL;
- candidate turns carry exact UUID/hash identity.

# 6. Validation outcomes

```text
SUFFICIENT
NEEDS_MORE_RECENT
NEEDS_TARGETED_HISTORY
UNRESOLVABLE_WITH_TRANSCRIPT
BOUND_EXHAUSTED
```

# 7. Configurable prototype bounds

```text
max_contiguous_lookback_exchanges = 20
max_targeted_candidate_turns_per_search = 8
max_scope_expansion_cycles = 3
max_total_injected_history_tokens = model-safe host budget
```

# 8. Output

`CONVERSATION_PACKET` includes resolver run/revision, turn/conversation IDs, raw prompt hash, transcript commit sequence, exact included recent/targeted turn identities+hashes, unresolved refs, status, validation, and packet hash.

# 9. Handoff

Intent receives:

```text
EXACT RAW USER PROMPT
+
VALIDATED CONVERSATION_PACKET
```

Recipe 0 does not rewrite the prompt or replace transcript evidence with an invented summary.

# 10. Failure

If transcript bounds cannot resolve a reference, Intent receives the raw prompt plus explicit unresolved state. It must preserve uncertainty rather than guess; later Context/durable memory/user clarification may resolve it under their own authority.

# 11. v0.1 performance rule

When `fast_path_enabled=true` and the host proves an exact D0 response before history resolution is semantically necessary, the deterministic path may bypass Recipe 0's learned call while still creating auditable host artifacts. When the toggle is OFF, the normal learned-eligible path is used.

# 12. Open-continuation cue — 2026-09-03 correction

A completed exchange may intentionally leave the conversation waiting for the user's next input.
A current prompt can therefore look grammatically self-contained while still deriving its role from the
immediately preceding exchange. Example:

```text
Turn N user: I want to edit my journal.
Turn N final: Sure — what would you like to add or change?
Turn N+1 user: I dreamed of pink elephants again last night. I woke up to a broken toe!
```

Without an explicit continuation cue, `SCOPE_PROPOSAL` could incorrectly classify Turn N+1 as
`SUFFICIENT_WITHOUT_HISTORY` and lose the journal-edit frame.

## 12.1 Host-owned continuation metadata

`current_transcript_metadata` gains one fixed-shape host field:

```json
{
  "continuation_state": {
    "status": "AWAITING_USER_INPUT",
    "source_turn_uuid": "TURN-N",
    "reason_code": "USER_INFORMATION_NEEDED"
  }
}
```

When no continuation is pending:

```json
{
  "continuation_state": {
    "status": "NONE",
    "source_turn_uuid": null,
    "reason_code": null
  }
}
```

This is technical transcript metadata only. It carries no semantic summary, journal payload,
project-memory fact, or hidden model-written context. The host may set `AWAITING_USER_INPUT` only
from an authoritative completed-turn state that explicitly requires additional user information.
The source must identify the immediately preceding completed user/final-response exchange.

## 12.2 Resolver behavior

An active continuation marker forbids a zero-history decision based only on the fact that the current
utterance can stand alone grammatically. The previous exchange may define what role the utterance is
playing.

Prototype rule:

1. host validates the continuation marker against the immediately preceding completed exchange;
2. host prefetches exactly that one exchange for `SCOPE_VALIDATION`;
3. `SCOPE_VALIDATION` decides whether the exchange is actually required to interpret the current turn;
4. if required, it is frozen into the Conversation Packet;
5. if unrelated, the prefetched exchange is discarded and the Conversation Packet remains zero-history.

To preserve minimum-sufficient history, `SCOPE_VALIDATION` therefore gains one legal status value:

```text
SUFFICIENT_WITHOUT_HISTORY
```

This status means the host-prefetched continuation exchange is not required for the current turn and
must not be projected into Intent. The existing `SUFFICIENT` status means the supplied transcript
evidence is required and sufficient.

## 12.3 Marker lifetime

The continuation marker is a one-next-turn cue. It is consumed when Recipe 0 freezes the next
Conversation Packet. It does not become durable semantic memory and does not continue across later
turns unless a later completed turn independently establishes a new `AWAITING_USER_INPUT` state.

## 12.4 Required tests

```text
test_r0_open_continuation_prefetches_exact_prior_exchange
test_r0_open_continuation_self_contained_payload_keeps_required_frame
test_r0_open_continuation_unrelated_turn_drops_prefetched_history
test_r0_open_continuation_marker_is_one_turn_only
test_full_journal_edit_elicitation_then_exact_payload
```

Journal integration expectation:

```text
Turn N:   "I want to edit my journal."
          -> no journal tool call; final response solicits edit content
          -> host marks AWAITING_USER_INPUT

Turn N+1: "I dreamed of pink elephants again last night. I woke up to a broken toe!"
          -> Recipe 0 supplies exactly Turn N when needed
          -> Intent interprets current text as journal-edit content
          -> exact current user text remains available as the eventual journal payload
```

The word `again` alone does not authorize older transcript or journal retrieval. Additional history is
requested only under normal Recipe 0/Context authority if a separate requirement genuinely needs it.

