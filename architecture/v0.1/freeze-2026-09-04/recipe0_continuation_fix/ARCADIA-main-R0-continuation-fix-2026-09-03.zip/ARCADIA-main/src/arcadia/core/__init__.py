"""Deterministic host-authority primitives."""
