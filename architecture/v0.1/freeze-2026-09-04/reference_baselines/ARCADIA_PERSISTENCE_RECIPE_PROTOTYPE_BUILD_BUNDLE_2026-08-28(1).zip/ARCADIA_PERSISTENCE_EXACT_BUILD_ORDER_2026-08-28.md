# A.R.C.A.D.I.A. — Persistence Prototype Exact Build Order
**Date:** 2026-08-28  
**Companion:** `ARCADIA_PERSISTENCE_RECIPE_PROTOTYPE_BUILD_SPEC_2026-08-28.md`

This is the command-window implementation checklist. It does not replace the full Persistence specification.

## Rule

Do not begin a later phase until the preceding phase gate passes.

## P-A — Foundation / migration
- [ ] P-A01 Freeze parent checkpoint beside Persistence work.
- [ ] P-A02 Add Persistence schema/version constants.
- [ ] P-A03 Add host Persistence policy snapshot.
- [ ] P-A04 Reserve/verify `system_meta.memory_commit_seq`.
- [ ] P-A05 Add semantic short-ID counter strategy.
- [ ] P-A06 Apply `001_semantic_memory.sql`.
- [ ] P-A07 Test migration transaction/rollback.
- [ ] P-A08 Verify SQLite pragmas/schema.

**Gate:** clean DB initializes; no model dependency.

## P-B — Semantic models
- [ ] P-B01 Entity
- [ ] P-B02 Claim
- [ ] P-B03 Alias
- [ ] P-B04 ClaimTransition
- [ ] P-B05 Conflict
- [ ] P-B06 EntityMerge
- [ ] P-B07 Provenance
- [ ] P-B08 MemoryTransaction/Mutation
- [ ] P-B09 CommitReceipt
- [ ] P-B10 Frozen enums

**Gate:** canonical JSON round-trip and schema validation pass.

## P-C — Read repository / snapshots
- [ ] P-C01 Read repository
- [ ] P-C02 Entity lookup
- [ ] P-C03 Alias normalization
- [ ] P-C04 Alias search
- [ ] P-C05 FTS maintenance/query
- [ ] P-C06 Active claims
- [ ] P-C07 Contested claims
- [ ] P-C08 Transition history
- [ ] P-C09 Provenance retrieval
- [ ] P-C10 Merged-entity canonicalization
- [ ] P-C11 Memory snapshot builder
- [ ] P-C12 Snapshot row hashes

**Gate:** exact frozen memory snapshot reproducible/hash-verifiable.

## P-D — Host-only write repository
- [ ] P-D01 Write repository authority boundary
- [ ] P-D02 UUID allocation
- [ ] P-D03 E/M/CF short-ID allocation
- [ ] P-D04 `BEGIN IMMEDIATE`
- [ ] P-D05 commit-seq compare/increment
- [ ] P-D06 CREATE_ENTITY
- [ ] P-D07 CREATE_CLAIM
- [ ] P-D08 SUPERSEDE_CLAIM
- [ ] P-D09 RETRACT_CLAIM
- [ ] P-D10 SET_CLAIM_CONTESTED
- [ ] P-D11 alias mutations
- [ ] P-D12 conflict mutations
- [ ] P-D13 entity merge
- [ ] P-D14 provenance
- [ ] P-D15 transaction/mutation audit
- [ ] P-D16 rollback verification
- [ ] P-D17 post-commit verification
- [ ] P-D18 PRC receipt

**Gate:** scripted host-only mutations pass; rollback leaves zero partial state.

## P-E — Input preparation
- [ ] P-E01 Decision obligations normalized
- [ ] P-E02 Reconciliation candidates normalized
- [ ] P-E03 Context-origin advisory candidate patch
- [ ] P-E04 provenance validation
- [ ] P-E05 upstream integrity gate
- [ ] P-E06 per-item lookup intent
- [ ] P-E07 bounded entity candidate retrieval
- [ ] P-E08 expansion counters

**Gate:** each item receives a bounded frozen memory snapshot.

## P-F — Persistence Assessor
- [ ] P-F01 input schema
- [ ] P-F02 output schema
- [ ] P-F03 canonical prompt
- [ ] P-F04 fresh-KV runner
- [ ] P-F05 host validator
- [ ] P-F06 diagnostics
- [ ] P-F07 repair x2
- [ ] P-F08 NEEDS_MORE_MEMORY loop
- [ ] P-F09 fixtures
- [ ] P-F10 independent slice test

**Gate:** Assessor passes before Composer integration.

## P-G — Persistence Composer
- [ ] P-G01 plan schema
- [ ] P-G02 canonical prompt
- [ ] P-G03 fresh-KV runner
- [ ] P-G04 obligation coverage
- [ ] P-G05 candidate coverage
- [ ] P-G06 temp refs
- [ ] P-G07 single-current validator
- [ ] P-G08 transition validator
- [ ] P-G09 alias validator
- [ ] P-G10 conflict validator
- [ ] P-G11 merge-cycle validator
- [ ] P-G12 policy validator
- [ ] P-G13 provenance validator
- [ ] P-G14 repair x2
- [ ] P-G15 independent fixtures

**Gate:** valid semantic plans only; still no model SQL authority.

## P-H — Commit bridge
- [ ] P-H01 plan -> host mutation objects
- [ ] P-H02 recheck commit seq
- [ ] P-H03 stale-snapshot abort
- [ ] P-H04 one stale-snapshot re-evaluation
- [ ] P-H05 permanent ID allocation after validation
- [ ] P-H06 atomic SQL transaction
- [ ] P-H07 semantic verification
- [ ] P-H08 immutable PRC
- [ ] P-H09 ledger append
- [ ] P-H10 Completion handoff

**Gate:** only PRC SUCCESS proves write.

## P-I — Context read integration
- [ ] P-I01 expose read repository only
- [ ] P-I02 record `memory_commit_seq`
- [ ] P-I03 active filters
- [ ] P-I04 historical/search-only aliases
- [ ] P-I05 contested warnings
- [ ] P-I06 expiry
- [ ] P-I07 prove Recipe 0 has no semantic-memory API

**Gate:** next-turn Context retrieves memory without write authority.

## P-J — End-to-end stress gate
- [ ] P-J01 new Entity
- [ ] P-J02 duplicate Claim
- [ ] P-J03 change
- [ ] P-J04 correction
- [ ] P-J05 multi-current
- [ ] P-J06 explicit remember
- [ ] P-J07 no-change remember
- [ ] P-J08 forget/retract
- [ ] P-J09 advisory save
- [ ] P-J10 advisory ignore
- [ ] P-J11 derived inference
- [ ] P-J12 external provenance
- [ ] P-J13 time expiry
- [ ] P-J14 conflict create
- [ ] P-J15 conflict resolve
- [ ] P-J16 identity ambiguity
- [ ] P-J17 historical alias
- [ ] P-J18 search-only corrected alias
- [ ] P-J19 merge
- [ ] P-J20 stale snapshot
- [ ] P-J21 rollback
- [ ] P-J22 policy-blocked secret
- [ ] P-J23 bad upstream hash
- [ ] P-J24 invented UUID
- [ ] P-J25 SQL attempt
- [ ] P-J26 obligation coverage failure
- [ ] P-J27 candidate coverage failure
- [ ] P-J28 transcript mutation attempt
- [ ] P-J29 Completion-status attempt
- [ ] P-J30 full Recipe 0→6 then next-turn memory retrieval

**Final gate:** NO-GO to Completion until P-J01 through P-J30 pass.
