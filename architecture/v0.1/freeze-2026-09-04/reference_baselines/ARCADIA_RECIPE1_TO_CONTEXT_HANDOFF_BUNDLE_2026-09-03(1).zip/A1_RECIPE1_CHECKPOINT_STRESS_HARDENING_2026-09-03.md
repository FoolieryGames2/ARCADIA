# A1 Recipe 1 Checkpoint Stress Hardening — 2026-09-03

Decision: **D-0033**  
Evidence: **E-0035**  
Subject checkpoint: `ARCADIA-main_A1_INTENT_COMMENT_FREEZE_2026-09-03.zip`  
Hardened candidate: `ARCADIA-main_A1_RECIPE1_STRESS_HARDENED_2026-09-03.zip`

## Verdict

**PASS after deterministic hardening; the untouched checkpoint is not promoted as the hardened baseline.**

The original Recipe-1 checkpoint was structurally strong: its external deterministic subset passed **562 tests**, source compilation passed, and both retained five-slice full-pipeline references passed the static checker. However, deliberately adversarial packets that remained JSON-schema-valid exposed several host-verifiable provenance, preservation, and presentation gaps. These were deterministic contract defects rather than learned-quality questions, so they were fixed in host validation and locked as regression tests before moving into Recipe 2 / Context.

No learned specialist received broader authority. All five Recipe-1 learned modes remain PRE_VERSION, `dispatch_enabled=False`, and non-production-qualified until the broader A1/runtime gates close.

## Baseline qualification context

External stress environment:

- Python: **3.13.5**
- Arcadia pinned runtime: **Python 3.12**
- Hypothesis: **not installed in this sandbox**
- Therefore this report does **not** replace the canonical Windows Python 3.12 `check.bat` qualification run.

Baseline external deterministic subset exclusions:

- `tests/unit/core/test_canonical_json.py` — imports unavailable Hypothesis
- `tests/unit/core/test_ids.py` — imports unavailable Hypothesis
- `tests/unit/test_environment.py` — intentionally rejects Python 3.13.5 because Arcadia pins Python 3.12

## Stress findings and hardening

### F-01 — Prompt Analyst question could be omitted by Organizer

**Severity:** High  
**Original behavior:** ACCEPT

Organizer's deterministic requirement-coverage check covered Prompt Analyst `tasks[]` and `directions[]`, but not `questions[]`. A question could therefore be present in an accepted Prompt Analyst artifact, omitted from the Organizer requirement backbone, and still pass validation.

**Hardening:** `questions[]` are now requirement-bearing alongside `tasks[]` and `directions[]`. Every such accepted item must be covered by at least one Organizer requirement basis.

**Regression:** `test_question_items_are_requirement_bearing_and_cannot_be_silently_dropped`

---

### F-02 — Requirement provenance could be cross-wired

**Severity:** High  
**Original behavior:** ACCEPT

A requirement could cite valid Prompt Analyst basis items while supplying unrelated-but-globally-legal `SPAN_*` provenance. Schema validity and global source membership were insufficient to prove that the requirement's source refs actually belonged to its cited basis items.

**Hardening:**

- every cited basis item must overlap the requirement source set;
- requirement `source_refs[]` must be a subset of the union of the cited basis items' source refs;
- constraint source refs must remain inside the requirement's source refs.

**Regression:** `test_requirement_source_refs_must_cohere_with_cited_basis_items`

---

### F-03 — Context/memory/blocker provenance could cross requirements

**Severity:** High  
**Original behavior:** ACCEPT

A Context need, memory candidate, or unresolved blocker could claim to serve one requirement while citing a legal source span carried only by another requirement.

**Hardening:** the source refs on Context needs, memory candidates, and unresolved blockers must be supported by the requirement(s) each object claims to serve.

**Regression:** `test_context_memory_and_blocker_sources_must_come_from_requirements_they_serve`

---

### F-04 — Meaning lookup obligation could disappear at Organizer

**Severity:** High  
**Original behavior:** ACCEPT

Meaning can explicitly mark a source as `context_lookup_needed=true`. If that source was carried into an Organizer requirement, Organizer could previously emit no Context need and set clarification to `not_required`, silently losing an already-identified grounding obligation.

**Hardening:** for every requirement/source pair that carries a Meaning lookup-worthy ref, that exact pair must be covered by a Context need.

**Regression:** `test_lookup_worthy_requirement_source_requires_context_need_coverage`

---

### F-05 — Prompt Analyst unresolved provenance could disappear at Organizer

**Severity:** High  
**Original behavior:** ACCEPT

An accepted Prompt Analyst unresolved item could be carried by a requirement yet disappear from both Organizer Context needs and blockers.

**Hardening:** every requirement/source pair that carries Prompt Analyst unresolved provenance must remain represented by either:

- a Context need for that requirement/source; or
- an unresolved blocker for that requirement/source.

**Regression:** `test_prompt_unresolved_requirement_source_requires_context_or_blocker_coverage`

---

### F-06 — Spell uncertainty records could duplicate/overlap one source span

**Severity:** Medium  
**Original behavior:** ACCEPT

Two separate `uncertain_corrections[]` records could use different `EDIT_*` refs over the same or overlapping raw span. The intended representation is one uncertainty record with multiple `candidate_replacements[]`.

**Hardening:** uncertainty records must be source-ordered and mutually non-overlapping, in addition to remaining disjoint from applied edits.

**Regression:** `test_uncertain_records_must_be_source_ordered_and_non_overlapping_with_each_other`

---

### F-07 — Spell edit-kind labels could hide deterministic category violations

**Severity:** Medium  
**Original behavior:** ACCEPT

Examples such as `cat -> dog` labeled `capitalization` and `like -> hate` labeled `punctuation` passed reconstruction because reconstruction proves *where* text changed, not whether the claimed category was truthful.

**Hardening:**

- `capitalization` may change case only (`casefold()` content must match);
- `punctuation` must preserve the same alphanumeric word runs.

A declared `spelling` change can still be linguistically or semantically wrong while structurally valid. That is deliberately **not** guessed by deterministic heuristics; it remains a model qualification/training concern.

**Regression:** `test_capitalization_and_punctuation_edit_kinds_cannot_hide_word_changes`

---

### F-08 — Duplicate Prompt Analyst controls could evade duplicate detection by ref order

**Severity:** Low/Medium  
**Original behavior:** ACCEPT

Two otherwise identical control events with the same `source_refs[]` in different array order could be treated as different events.

**Hardening:** duplicate identity treats the source refs as a provenance set for this purpose.

**Regression:** `test_control_signal_duplicate_is_order_insensitive_over_source_ref_set`

---

### F-09 — Intent Commenter allowed obvious execution/future-work claims

**Severity:** Medium  
**Original behavior:** ACCEPT for tested forms

Presentation-only Commenter accepted obvious authority leaks including present-passive and future commitments such as:

- `The requested file is saved...`
- `I will save...`
- `I'll use web_search...`
- `Arcadia will save...`

**Hardening:** broadened deterministic obvious-execution/completion/commitment guards. Commenter may describe requested work but cannot claim or commit to execution.

**Regression:** `test_execution_guard_rejects_present_passive_and_future_commitments`

---

### F-10 — Protected-literal detector produced substring false positives

**Severity:** Medium usability / false rejection  
**Original behavior:** REJECTED innocent wording

Protected literal `Ready.` was treated as altered when the comment merely contained the unrelated word `already`, because the earlier heuristic matched an alphanumeric signature as a raw substring.

**Hardening:** literal-alteration detection now uses boundary-aware alphanumeric-run matching rather than naive substring signatures.

**Regression:** `test_protected_literal_detector_does_not_match_substring_inside_unrelated_word`

## Cross-stage identity review

The stress review also preserved the previously repaired cross-stage invariant:

- Prompt Analyst consumes the **exact accepted Meaning artifact**, not a newly reconstructed equivalent;
- Organizer consumes the **exact accepted Prompt Analyst artifact** and Meaning artifact;
- schema equivalence alone is not sufficient for accepted-artifact handoff identity.

This is especially important before training/replay data is generated: a valid-looking reconstructed artifact cannot silently replace the actual accepted upstream result.

## Final verification

### Focused Recipe-1 contract stress suite

```text
69 passed
```

Focused modules:

- Spell
- Prompt Analyst
- Intent Organizer
- Intent Comment

### External deterministic repository subset

```text
572 passed
```

This is **+10 regression tests** over the original 562-test checkpoint.

### Source compilation

```text
PASS
```

### Retained full-pipeline static references

Both retained copies pass:

```text
envelope tags: open=88 close=88
envelopes: templates=1 actual_slice_calls=87
JSON fences parsed strictly: 110
specialist modes represented: 20
PASS
```

The reference slices retain their existing per-slice call counts and adapter-load simulation results.

## Residual qualification-owned risks — intentionally not disguised as deterministic proof

### 1. Spelling semantic correctness

The host now proves exact source spans, reconstruction, uncertainty structure, capitalization semantics, and punctuation semantics. It does **not** claim it can prove that every arbitrary `spelling` substitution is linguistically correct. For example, a declared `like -> hate` spelling edit is structurally reconstructible but semantically wrong. That belongs in locked specialist evaluation, contrastive examples, and failure mining.

### 2. Natural-language semantic faithfulness

The host can prove provenance, coverage, IDs, graph legality, Context/memory/blocker preservation, literal constraints, and Commenter authority limits. It cannot completely prove that free-text semantic descriptions are faithful paraphrases. That remains a qualification-set problem.

### 3. Dynamic tool/capability-name leakage in Commenter prose

Commenter intentionally does not receive the capability registry. Obvious future execution commitments are blocked, but exhaustive dynamic scanning against the runtime's current capability/tool namespace belongs in the later host presentation/runtime layer.

### 4. Runtime accepted-artifact identity

Exact identity is exercised in retained fixture/tests, but the production host controller, authoritative ID allocator, and runtime handoff implementation are later build/runtime work. A1 contracts define the invariant; they do not constitute runtime qualification.

### 5. Canonical environment qualification

This report is not the canonical Python 3.12 Windows gate. The pinned workstation `check.bat` run remains mandatory before broader Gate A1 closure.

## Promotion recommendation

Promote the **stress-hardened candidate**, not the untouched Intent Comment checkpoint, as the next Recipe-1 source checkpoint.

Recipe-1 learned-contract status after hardening:

```text
Spell             PRE-1 contract generation complete + stress hardened
Term / Meaning    PRE-1 contract generation complete
Prompt Analyst    PRE-1 contract generation complete + stress hardened
Intent Organizer  PRE-1 contract generation complete + stress hardened
Intent Comment    PRE-1 contract generation complete + stress hardened
```

This does **not** close Gate A1 globally. It makes Recipe 1 a substantially stronger basis for beginning Recipe 2 / Context contract review.
