# A.R.C.A.D.I.A. — CONTEXT FREEZE STARTING POINT

**Date:** 2026-09-03  
**Status:** PROPOSED / NOT YET IMPLEMENTED OR FROZEN  
**Base source:** `ARCADIA-main_A1_RECIPE1_STRESS_HARDENED_2026-09-03.zip`

## Freeze order

```text
1. Accepted Intent root / Context ingress
2. Host Context Router + LaneRequest
3. Host source-map / narrow direct source projection
4. Evidence Candidate Packet
5. Evidence Specialist
6. Host evidence validator
7. Context Lane Commentator
8. Host Cxxx allocator + lane report freezer
9. Final Context Synthesis
10. Host Context freezer / Decision handoff
11. Joint Context stress test
```

## Boundary rule

Intent stays immutable. Context appends grounding/resolution/conflict/unresolved state. Context must not rewrite Intent.

Raw prompt is deliberately cut before Intent Organizer and should not reappear as default Context-model input. Surviving `SPAN_*` refs must instead resolve through a durable host-owned hash-bound source map.

## Proposed Context ingress

```json
{
  "intent_artifact_ref": "...",
  "intent_hash": "sha256:...",
  "source_map_ref": "...",
  "source_map_hash": "sha256:...",
  "in_scope_requirements": [],
  "context_needs": [],
  "clarification_state": "not_required",
  "unresolved_blockers": [],
  "split_library_ref": "...",
  "split_library_version": "...",
  "split_library_hash": "sha256:...",
  "routing_limits": {}
}
```

## Host Router output

Either zero evidence lanes, or host-owned lane requests such as:

```json
{
  "lane_id": "L001",
  "split_id": "project_continuity",
  "split_version": 1,
  "intent_refs": ["R002", "ICN001"],
  "lane_purpose": "Resolve the authoritative project notes destination.",
  "source_refs": ["SPAN_4"],
  "retrieval_scope": "bounded host-defined scope",
  "direct_source_refs": ["SPAN_4"]
}
```

Host owns lane count, lane IDs, Split selection, retrieval, narrowing, candidate limits, direct source projection, and termination mechanics.

## Evidence packet direction

Prefer host-defined evidence item refs rather than model-copied support text:

```json
{
  "evidence_id": "E002",
  "source_kind": "semantic_memory",
  "authority_class": "...",
  "metadata": {},
  "items": {
    "EITEM_1": {
      "text": "The current stored A.R.C.A.D.I.A. test runtime version is 6.3.2."
    }
  }
}
```

Evidence Specialist references `EITEM_*` support rather than copying text solely for provenance.

## Evidence Specialist core question

> Against this exact Context split and current Intent need, what does the supplied evidence actually support?

Semantic outcomes remain conceptually:

```text
accepted
partial
no_match
conflict
unresolved
```

Mechanical lane status remains separate:

```text
completed
no_candidates
failed_validation
```

Honest `partial`, `no_match`, `conflict`, and `unresolved` can still be valid completed Context.

## Learned hats

- Evidence Specialist: dedicated Context adapter, bounded semantic evidence judgment only.
- Context Lane Commentator: `CONVERSATIONAL_HOWARD`, fresh context, proposes supported/inference/unresolved Context points.
- Final Context Synthesis: `CONVERSATIONAL_HOWARD`, fresh context, combines accepted Intent projection + optional host direct input + exact completed lane reports.
- Router: host-only, no adapter.

## No-SQLite path

Zero lanes remains a first-class valid Context path. Context is not synonymous with retrieval.

## Final handoff principle

Two layers:

```text
1. immutable ACCEPTED INTENT reference/artifact
2. CONTEXT REPORT containing later grounding/resolution/conflict/unresolved state
```

Never flatten them into one rewritten Intent-like blob.
