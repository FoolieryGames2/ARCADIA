# A.R.C.A.D.I.A. THREAD HANDOFF — RECIPE 1 COMPLETE / CONTEXT NEXT

**Date:** 2026-09-03  
**Project:** A.R.C.A.D.I.A. — Adaptive Runtime for Compartmentalized Agents, Decisions, Interaction & Automation  
**Purpose:** Standalone continuation handoff for a new thread after completing and stress-hardening Recipe 1 and immediately before freezing Recipe 2 / Context.  
**Authority note:** This handoff records decisions, corrections, and continuation context from the working thread that are not safely recoverable from the older prototype documentation alone. Existing frozen/source documents still outrank this handoff if an explicit contradiction is discovered. Where this handoff says **PROPOSED / NOT YET FROZEN**, do not treat it as landed source.

---

## 1. START FROM THIS CHECKPOINT

Current working checkpoint:

`ARCADIA-main_A1_RECIPE1_STRESS_HARDENED_2026-09-03.zip`

SHA-256:

`3e37bd3197d740acd27847d50b5d36583a41644f1f3a200833803e4e12aac537`

Stress-hardening patch:

`ARCADIA_A1_RECIPE1_CHECKPOINT_STRESS_HARDENING_2026-09-03.patch`

Patch SHA-256:

`b3acfa7cf7b71af056276ae62702dd31777ceec2d036982622bda5c5a469a92b`

Evidence report:

`evidence/phase_a1/A1_RECIPE1_CHECKPOINT_STRESS_HARDENING_2026-09-03.md`

Evidence SHA-256:

`d37122d4aec92ca552093367e481ae1a9e901e378fc088468c1ff5da1dacd8de`

### Verification standing at handoff

- 572 deterministic repository tests PASS in the external sandbox.
- Source compilation PASS.
- Both retained five-slice references PASS.
- Reference accounting remains:
  - 87 actual learned calls;
  - 1 syntax/template envelope;
  - 110 strict JSON blocks;
  - all 20 logical specialist modes represented.
- External sandbox is Python 3.13.5, while A.R.C.A.D.I.A. is pinned to Python 3.12.
- The deterministic external run excludes exactly:
  - `test_canonical_json.py` because Hypothesis is unavailable in this sandbox;
  - `test_ids.py` because Hypothesis is unavailable in this sandbox;
  - the environment gate that correctly rejects Python 3.13.5 against the pinned 3.12 contract.
- **Do not claim Gate A1 closed.** The canonical Windows Python 3.12 `check.bat` qualification still needs to be run after the latest Recipe-1 changes/hardening.
- All Recipe-1 learned contracts remain `PRE_VERSION`, T0/non-dispatchable pending the broader A1 gate.

---

## 2. WHERE THE PROJECT IS RIGHT NOW

The full recipe spine remains:

0. Conversation Resolver  
1. Intent  
2. Context  
3. Decision  
4. Tool / Execution — host-only  
5. Reconciliation  
6. Persistence  
7. Completion  
8. Result

### Recipe 1 is complete at A1 contract-generation level

```text
Spell             ✅
Term / Meaning    ✅
Prompt Analyst    ✅
Intent Organizer ✅
Intent Commenter ✅
Recipe-1 joint adversarial hardening ✅
```

The next unfinished A1 learned-contract section is Recipe 2 / Context.

---

## 3. RECIPE 0 + RECIPE 1 MODEL-HAT REEVALUATION

Immediately before moving into Context, the specialist jobs were reevaluated to make sure the contracts had not drifted into jobs that no longer fit the intended small specialist models.

### Important clarification about the old scoring discussion

The user was referring to the earlier **0.0–1.0 model-affinity / job-suitability scale**, not parameter count. The exact historic numeric table was not recovered in this thread, so **do not invent exact old scores**.

What was reaffirmed:

- Conversation Resolver still has a very strong specialist fit.
- Spell remains deliberately low model-dependence; the user remembers it around ~0.2 on the old affinity scale.
- Meaning remains a strong narrow semantic-specialist job.
- Prompt Analyst remains a strong narrow communication-classification job.
- Intent Organizer remains the hardest Recipe-1 role, but the new contract made it *more* small-model-friendly by removing raw-prompt interpretation at that stage, Context lane selection, model-built direct inputs, ID authority, graph validity, capability-state ownership, and several preservation checks.
- Intent Commenter remains an extremely strong presentation-only fit.
- No Recipe-0/Recipe-1 specialist was judged to have fallen into a bad middle ground where the host cannot verify it and a small specialist cannot reliably learn it.

**Conclusion at handoff:** the hats still fit. Recipe 0 and Recipe 1 are stable enough to move forward.

---

## 4. RECIPE 1 DECISIONS THE NEXT THREAD MUST NOT UNDO

### 4.1 Spell — D-0028, hardened under D-0033

Input exactly:

```text
raw_prompt
```

Output exactly:

```text
raw_prompt
normalized_prompt
spell_edits[]
uncertain_corrections[]
```

Core principles:

- Normalized prompt must be exactly reconstructible from authoritative raw prompt + declared applied edits.
- Uncertain corrections never mutate normalized text.
- Applied edit kinds are only `spelling | punctuation | capitalization`.
- Host now mechanically proves capitalization edits are genuinely case-only and punctuation edits preserve word content; it does **not** pretend it can judge whether every arbitrary `spelling` substitution is linguistically correct.
- Spell uncertainties cannot overlap the same source region under separate edit refs.
- Linguistic correctness of a declared spelling replacement remains qualification/training territory.

### 4.2 Term / Meaning — D-0027 + D-0029

Input exactly:

```text
raw_prompt
normalized_prompt
spell_uncertainties[]
linguistic_map{}
recipe0_transcript_evidence[]
```

Output exactly:

```text
terms[]
reference_candidates[]
lookup_worthy_terms[]
unresolved[]
```

Critical decisions:

- Host source refs are neutral `SPAN_*`, not semantic-looking `PATH_*`, `ACTION_*`, `CONTENT_*`, `TERM_*`, etc.
- Host supplies exact normalized offsets/text and closed structural `surface_hints[]` only.
- Host must not pre-solve Meaning with semantic hints such as save destination, memory request, project reference, research target, requirement, etc.
- Recipe-0 evidence uses exact `turn_uuid + speaker + text`; historical `exchange_ref` shapes are rejected.
- `lookup_worthy_terms[]` is a routing hint, not durable Context/SQLite authority.
- `raw_prompt` remains here for PRE-1 fidelity baseline, with an explicit future ablation obligation.

### 4.3 Prompt Analyst — D-0030, hardened under D-0033

Input exactly:

```text
raw_prompt
normalized_prompt
accepted meaning_artifact
neutral source_spans{}
```

Output exactly:

```text
topics[]
goals[]
tasks[]
statements[]
questions[]
directions[]
approvals[]
interaction_mode
important_claims[]
unresolved_items[]
control_signals[]
```

Critical decisions:

- Ordinary communication records use `TGT_*` + `SPAN_*` provenance.
- Claims use `CLAIM_*`.
- Unresolved items use `UNRESOLVED_*`.
- Empty `control_signals[]` means none; synthetic `NONE` was removed.
- Analyst identifies communication structure only. It does not create requirements/dependencies, judge truth, retrieve Context, choose tools, persist, or answer.
- Duplicate control detection is order-insensitive over the same source-ref set.
- Questions are requirement-bearing downstream just like tasks/directions and cannot silently disappear.

### 4.4 Intent Organizer — D-0031, hardened under D-0033

This is the deliberate learned-boundary **RAW PROMPT CUT POINT**.

Input exactly:

```text
accepted meaning_artifact
accepted prompt_analysis_artifact
compact canonical-hash-bound capability_snapshot
```

**Organizer does not receive raw_prompt, normalized_prompt, or another source-span packet.**

Output exactly:

```text
primary_intent
secondary_intents[]
requirements[]
requirement_groups[]
dependencies[]
context_needs[]
capability_candidates[]
memory_candidates[]
clarification_state
unresolved_blockers[]
control_signals[]
```

Critical decisions:

- Organizer proposals use local `REQ_*`; host allocates authoritative `Rxxx` only after validation.
- Requirements cite upstream `TGT_*` basis refs and `SPAN_*` provenance.
- Dependency kinds only:
  - `value_dependency`
  - `content_dependency`
  - `ordering_dependency`
- Clarification state is one enum:
  - `not_required`
  - `context_resolution_first`
  - `user_clarification_required`
- Memory action only:
  - `remember`
  - `update`
  - `forget`
- Organizer may say **what needs grounding**, but **cannot choose Context lane/Split names**.
- Historical model-built `direct_context_inputs` / `DIRECT_*` objects were removed. Host may derive narrow direct input later from accepted exact source refs.
- Every Analyst task, direction **and question** must be covered by at least one requirement.
- Requirement provenance must cohere with its cited basis items.
- Context needs, memory candidates, and blockers cannot cross-wire source provenance from unrelated served requirements.
- Any Meaning source with `context_lookup_needed=true` that is carried into a requirement must remain represented by a Context need for that requirement/source pair.
- Any Analyst unresolved source carried into a requirement must remain represented by a Context need or unresolved blocker.
- Exact accepted Meaning/Analyst artifacts must pass forward **unchanged**, not as independently rebuilt schema-valid equivalents.

### 4.5 Intent Commenter — D-0032, hardened under D-0033

Commenter is optional `PRESENTATION_ONLY` on the existing Conversational Howard adapter.

It receives only a host-built presentation-safe accepted-Intent projection.

It does **not** receive raw/normalized prompt, Meaning/Analyst artifacts, source spans, capability IDs, Context routing internals, direct-input objects, or execution state.

Output exactly:

```text
comment
covered_requirement_ids[]
```

Critical decisions:

- Coverage must exactly equal every host-selected Rxxx in supplied order.
- Commenter cannot add facts, requirements, tools, memory, blockers, clarification decisions, or execution claims.
- Obvious present/future execution commitments are rejected.
- Protected literal matching is boundary-aware; e.g. protected `Ready.` must not falsely trigger on `already`.
- Repeated Commenter failure can fall back to deterministic boring host wording.
- **Commenter never feeds Context or any semantic downstream stage.**

---

## 5. CROSS-STAGE INVARIANTS DISCOVERED IN THIS THREAD

These are important enough to preserve beyond the individual schemas.

### 5.1 Exact accepted artifact identity

A downstream specialist must receive the exact accepted upstream artifact value, not a separately reconstructed schema-valid imitation.

This defect was found in all five retained Prompt Analyst fixture handoffs during Organizer freeze and repaired.

Required invariant:

```text
Accepted Meaning output
    == exact value ==
Prompt Analyst Meaning input

Accepted Prompt Analyst output
    == exact value ==
Intent Organizer Analyst input
```

Continue this principle into Context.

### 5.2 Host-verifiable defects belong in host validation

The Recipe-1 stress pass deliberately moved the following out of learned qualification and into deterministic rejection:

- dropped question;
- cross-wired requirement provenance;
- cross-wired Context need/memory/blocker provenance;
- dropped Meaning Context-lookup obligation;
- dropped unresolved obligation;
- overlapping Spell uncertainties;
- fake capitalization/punctuation edit classes;
- duplicate control events under reversed refs;
- obvious Commenter execution claims;
- protected-literal substring false positives.

Do the same in Context: if a defect can be proven mechanically, do not make the model learn around it.

### 5.3 Learned semantic correctness is still allowed to remain learned

Do not overfit host heuristics to questions such as:

- whether a spelling substitution is linguistically correct;
- whether a free-text semantic paraphrase is genuinely faithful;
- whether bounded evidence actually supports a human-meaning conclusion.

Those belong to specialist qualification, adversarial/contrastive datasets, and later host-scored rollout failure mining.

---

## 6. THE RAW-PROMPT / PRESERVED-DATA EXPERIMENT

This is a deliberate architectural experiment and should not disappear.

Current path:

```text
Spell             raw available
    ↓
Meaning           raw + normalized available
    ↓
Prompt Analyst    raw + normalized available
    ↓
==============================
      RAW PROMPT CUT POINT
==============================
    ↓
Intent Organizer  structured accepted artifacts only
    ↓
Accepted Intent
```

The goal is **not** to preserve raw prompt forever out of convenience.

The goal is to test whether exact preserved source items, provenance, Meaning, and Analyst artifacts can safely carry the needed information farther down the pipeline.

If downstream quality fails because something needed was lost, improve the preserved structured data rather than automatically reintroducing the whole raw prompt.

### Consequence for Context

**Context should not casually reintroduce raw_prompt or normalized_prompt as default learned inputs.**

However, surviving `SPAN_*` references need a durable host-owned provenance bridge so the host can supply exact bounded source material when a Context specialist genuinely needs to interpret it.

This leads directly to the proposed `source_map_ref + source_map_hash` boundary below.

---

# 7. INTENT → CONTEXT HANDOFF REVIEW — CURRENT CONCLUSION

The older Context prototype spec says Context's root packet includes raw prompt / normalized prompt / source spans / term candidates and that the full Intent packet remains available.

That was reasonable for the older generation, but Recipe 1 has now deliberately changed the boundary.

### Do not freeze the old handoff shape unchanged.

The newer design should preserve the old **semantic principle**:

> Intent remains immutable and Context cannot replace it with a lossy rewritten summary.

But implement that principle using an immutable host artifact + bounded projections, rather than giving every Context model the entire old Intent packet.

### Key reconciliation

A **host-built bounded projection is not a lossy replacement** when:

1. the complete Accepted Intent Artifact remains immutable and recoverable;
2. every projection carries the accepted artifact reference/hash;
3. omitted fields remain recoverable from that artifact;
4. source refs remain resolvable through a hash-bound source map;
5. the host chooses the projection;
6. no model is allowed to silently rewrite the upstream artifact.

---

# 8. PROPOSED ACCEPTED INTENT ARTIFACT — CONTEXT ROOT

**STATUS: PROPOSED / NOT YET IMPLEMENTED OR FROZEN.**  
This is the conceptual host-level root discussed immediately before thread handoff. Exact final field names should be reviewed against existing Artifact Envelope conventions before implementation.

```json
{
  "turn_uuid": "...",

  "intent_artifact_uuid": "...",
  "intent_revision": 1,
  "intent_hash": "sha256:...",
  "accepted": true,

  "conversation_packet_ref": "...",
  "conversation_packet_hash": "sha256:...",

  "provenance_roots": {
    "meaning_artifact_ref": "...",
    "meaning_artifact_hash": "sha256:...",

    "prompt_analysis_artifact_ref": "...",
    "prompt_analysis_artifact_hash": "sha256:...",

    "source_map_ref": "...",
    "source_map_hash": "sha256:..."
  },

  "primary_intent": "...",
  "secondary_intents": [],

  "requirements": [
    {
      "requirement_id": "R001",
      "basis_item_refs": ["TGT_2"],
      "source_refs": ["SPAN_1", "SPAN_3"],
      "requested_outcome": "...",
      "constraints": [
        {
          "source_refs": ["SPAN_3"],
          "description": "Preserve the supplied literal exactly.",
          "exact_value": "Ready."
        }
      ]
    }
  ],

  "requirement_groups": [],

  "dependencies": [
    {
      "from_requirement_id": "R001",
      "to_requirement_id": "R002",
      "dependency_kind": "value_dependency"
    }
  ],

  "context_needs": [
    {
      "context_need_id": "ICN001",
      "serves": ["R002"],
      "source_refs": ["SPAN_4"],
      "need": "Resolve the authoritative project notes destination."
    }
  ],

  "capability_candidates": [],
  "memory_candidates": [],

  "clarification_state": "context_resolution_first",
  "unresolved_blockers": [],
  "control_signals": [],

  "ready_for_context": true
}
```

### Intent artifact principles to preserve

- No raw prompt by default.
- No normalized prompt by default.
- No Commenter prose.
- No historical model-built `DIRECT_*` objects.
- Do not flatten typed constraints into generic strings if authoritative structure already exists.
- Do not flatten typed dependency edges into lossy shorthand.
- Do not reduce meaningful Context needs to bare `ICNxxx` IDs when Context requires the actual bounded semantic need.
- `source_map_ref/hash` is the durable bridge from surviving `SPAN_*` provenance to exact bounded source content.

---

# 9. CONTEXT FREEZE OUTPUT FROM THE END OF THIS THREAD

## 9.1 Recipe-2 architectural order

The existing Context design remains fundamentally sound:

```text
Accepted Intent
      ↓
HOST CONTEXT ROUTER
      ↓
Split selection / narrow scope
      ↓
No-evidence path OR host retrieval
      ↓
EVIDENCE SPECIALIST
      ↓
Host evidence validator
      ↓
CONVERSATIONAL HOWARD / CONTEXT LANE
      ↓
Host Context-point validator + Cxxx allocator
      ↓
Lane report freeze
      ↓
CONVERSATIONAL HOWARD / FINAL CONTEXT SYNTHESIS
      ↓
Host Context validator/freezer
      ↓
Decision
```

### Model roster remains

- **Evidence Specialist:** one dedicated new Context adapter.
- **Context Lane Commentator:** reuse `CONVERSATIONAL_HOWARD` under a Context-lane logical mode.
- **Final Context Synthesis:** reuse `CONVERSATIONAL_HOWARD` under a separate fresh logical mode.
- **Context Router:** host-only. No router adapter.
- Fresh model context/KV boundary between learned calls remains mandatory.

## 9.2 First thing to freeze in Recipe 2

**Do not start by freezing Evidence Specialist prose/output.**

Start by freezing the **Context Ingress + Host Context Router + Lane Packet** so the Evidence Specialist's world is small, explicit, and host-authorized before its schema is finalized.

### Proposed Context ingress packet

**STATUS: PROPOSED.**

```json
{
  "intent_artifact_ref": "...",
  "intent_hash": "sha256:...",

  "source_map_ref": "...",
  "source_map_hash": "sha256:...",

  "in_scope_requirements": [
    {
      "requirement_id": "R002",
      "requested_outcome": "...",
      "constraints": []
    }
  ],

  "context_needs": [
    {
      "context_need_id": "ICN001",
      "serves": ["R002"],
      "source_refs": ["SPAN_4"],
      "need": "Resolve the authoritative project notes destination."
    }
  ],

  "clarification_state": "context_resolution_first",
  "unresolved_blockers": [],

  "split_library_ref": "...",
  "split_library_version": "...",
  "split_library_hash": "sha256:...",

  "routing_limits": {
    "max_lanes": null,
    "max_candidates_per_lane": null
  }
}
```

Numeric limits above should come from the existing settings/tuning authority rather than being invented during schema review.

## 9.3 Host Context Router output

The router is deterministic host logic. It chooses whether evidence lanes are needed and which host-owned Split definition governs each lane.

Conceptually:

```text
NO_CONTEXT_LANE_NEEDED
```

or one/more lane requests:

```json
{
  "lane_id": "L001",
  "split_id": "project_continuity",
  "split_version": 1,
  "intent_refs": ["R002", "ICN001"],
  "lane_purpose": "Resolve the authoritative project notes destination.",
  "source_refs": ["SPAN_4"],
  "retrieval_scope": "bounded host-defined scope",
  "direct_source_refs": ["SPAN_4"]
}
```

### Router authority

Host owns:

- whether zero/one/many lanes run;
- lane IDs;
- Split selection and Split version;
- retrieval source eligibility;
- deterministic narrowing;
- candidate count limits;
- direct narrow source projection;
- lane termination mechanics.

No learned model chooses or changes a Split.

## 9.4 Source-map requirement

Because raw prompt is cut before Organizer, opaque `SPAN_*` IDs cannot be the only thing Context receives when actual interpretation is needed.

Freeze a durable host-owned source map that can prove:

```text
SPAN_4 -> exact preserved text/item + source provenance
```

without passing the entire prompt.

Recommended properties:

- immutable/hashiable;
- tied to the accepted Intent provenance root;
- exact source text/items preserved;
- bounds/source origin preserved where applicable;
- Context host can project only the source items needed for one lane;
- learned Context adapters do not browse the whole map themselves.

## 9.5 Narrow direct input

Historical model-created `D001 / DIRECT_*` objects should **not** return as Organizer output.

If Context needs direct source material that is already known from accepted Intent provenance, the **host** derives a narrow direct input from exact accepted `SPAN_*` source items.

Example:

```json
{
  "source_ref": "SPAN_4",
  "text": "the project notes file"
}
```

If the bounded source item already has authoritative structured meaning, host may carry it directly. If human semantic judgment is needed, host may place it into a normal Context evidence lane with explicit source kind/authority.

## 9.6 Evidence Candidate Packet — revision to review next

The old Context examples often make the model copy free-text `support_spans` back out of evidence.

The new preferred direction is:

> Host owns exact evidence content. Model references host-defined exact evidence items.

Conceptual candidate:

```json
{
  "evidence_id": "E002",
  "source_kind": "semantic_memory",
  "authority_class": "...",
  "metadata": {},
  "items": {
    "EITEM_1": {
      "text": "The current stored A.R.C.A.D.I.A. test runtime version is 6.3.2."
    }
  }
}
```

Then Evidence Specialist should preferably say something like:

```json
{
  "evidence_id": "E002",
  "support_refs": ["EITEM_1"],
  "judgment": "..."
}
```

rather than copying the sentence itself just to establish provenance.

**This exact Evidence Specialist schema is NOT frozen yet. Review it next.**

## 9.7 Evidence Specialist hat

Core question remains excellent and should be preserved:

> Against this exact Context split and current Intent need, what does the supplied evidence actually support?

Evidence Specialist does not:

- query SQLite;
- select its Split;
- create evidence IDs;
- retrieve arbitrary history/memory;
- write memory;
- change Intent;
- execute tools;
- answer the user.

Host retrieves/scopes/hashes candidates first; model judges bounded semantics.

Current semantic-status vocabulary remains conceptually strong:

```text
accepted
partial
no_match
conflict
unresolved
```

Structural lane status remains separate:

```text
completed
no_candidates
failed_validation
```

Important principle:

`partial`, `no_match`, `conflict`, or `unresolved` can still be a **valid completed Context result**. Honest uncertainty is not a pipeline failure.

## 9.8 Context Lane Commentator hat

After Evidence Specialist output passes host validation, Conversational Howard proposes bounded Context points.

Current Context-point modes remain:

```text
supported
inference
unresolved
```

Host allocates authoritative `Cxxx` only after accepting the local proposal.

The lane commentator must preserve explicit conflicts/unresolved state and may not retrieve, invent support, mutate Intent, execute, persist, or answer.

## 9.9 Final Context Synthesis hat

Fresh Conversational Howard call.

Receives only:

```text
accepted Intent projection
optional host-built narrow direct input
completed validated Context loop reports
```

It composes the grounded working snapshot for Decision while preserving:

- current subject/job;
- relevant grounded Context points;
- resolved references;
- current constraints;
- relevant history;
- conflicts;
- unresolved items;
- support/source refs;
- explicit `important_do_not_assume` boundaries.

It cannot make a conflict disappear or choose a winner without supplied authority.

## 9.10 No-SQLite / no-evidence path remains a first-class PASS

Context is not synonymous with retrieval.

If accepted Intent already contains sufficient grounded state and the router selects zero evidence lanes:

```text
Accepted Intent
      ↓
Host Context Router
      ↓
zero lanes
      ↓
Final Context Synthesis
      ↓
Context handoff
```

This remains a normal valid path.

## 9.11 Final Context handoff remains two-layer

Preserve the old two-layer principle:

```text
1. ACCEPTED INTENT
   immutable upstream artifact/reference

2. CONTEXT REPORT
   what Context learned/resolved/derived afterward
```

Do not flatten the two into one rewritten semantic blob.

## 9.12 Selective re-entry remains important

Later authoritative results may trigger Context re-entry for only affected lanes.

Conceptually:

```text
new result affects lane A only
      ↓
rerun lane A
preserve lanes B/C/D
      ↓
new Context revision
```

Intent stays immutable; previous Context history stays auditable; replacement promotion should remain transactional rather than deleting the prior active revision early.

---

## 10. CONTEXT CONTRACT ISSUES TO REVIEW FIRST IN THE NEXT THREAD

Do these before implementing Recipe-2 learned schemas:

1. **Freeze the accepted Intent root / Context ingress projection.**
   - Reconcile final names with Artifact Envelope / registry conventions.
   - Decide whether `source_map_ref/hash` belongs directly in Accepted Intent or an attached provenance-root object.

2. **Freeze the source-map object.**
   - Exact item structure.
   - Hashing/versioning.
   - Legal origin classes.
   - Projection rules.

3. **Freeze Host Context Router output / LaneRequest.**
   - Zero-lane representation.
   - `lane_id` authority.
   - `split_id/version/hash` binding.
   - `intent_refs` exact namespace.
   - `source_refs` / direct-source projection.
   - routing limits from settings, not schema constants.

4. **Freeze Evidence Candidate Packet before Evidence Specialist output.**
   - Candidate metadata.
   - authority/source kind.
   - exact host evidence-item refs (`EITEM_*` or equivalent).
   - freshness/time metadata where Split requires it.
   - canonical hash of frozen candidate bundle.

5. **Then freeze Evidence Specialist input/output.**
   - Prefer refs to host evidence items rather than free-text support copying.
   - Preserve accepted/partial/rejected/conflict/unresolved distinctions.
   - Decide whether `rejected` remains a top-level semantic bucket or becomes a per-candidate judgment enum.
   - Keep semantic status distinct from mechanical lane status.

6. **Then freeze Context Lane Commentator.**
   - Local keys only; host allocates Cxxx.
   - conflict/unresolved preservation.

7. **Then freeze Final Context Synthesis.**
   - Ensure no raw prompt creep.
   - Ensure all lane reports are exact accepted artifacts.
   - Preserve do-not-assume/conflict/unresolved state.

8. **Joint Context stress pass before Decision.**

---

## 11. WHAT NOT TO DO IN THE NEXT THREAD

- Do not rebuild Recipe 1 unless a Context boundary test exposes a genuine upstream defect.
- Do not casually reintroduce raw prompt downstream just because the older Context spec included it.
- Do not let Organizer select Context lanes/Splits.
- Do not restore model-created `DIRECT_*` objects.
- Do not let Evidence Specialist query SQLite or any external source itself.
- Do not let schema-valid evidence judgment become synonymous with semantic truth.
- Do not allow Context to rewrite accepted Intent.
- Do not let Commenter output enter Context.
- Do not flatten conflicts/unresolved states simply to make the pipeline look successful.
- Do not make Context retrieval mandatory; zero lanes is a valid outcome.
- Do not claim A1 qualification until the canonical Python 3.12 gate and broader 20-mode joint review are complete.

---

## 12. TRAINING-RESEARCH TAKEAWAY TO KEEP USING

The 2026 specialist-training research was reviewed before Organizer and materially influenced the design philosophy, not project authority.

Keep applying this rule:

> Narrow learned job + executable strict contract + deterministic host scoring for mechanically provable failures + contrastive/negative qualification for semantic failures + later failure mining.

For Context this means especially:

- host scopes evidence;
- host owns provenance;
- host owns retrieval mechanics;
- host owns Split choice;
- model judges human meaning/relevance/conflict inside that box;
- deterministic failures become regression tests;
- semantic judgment quality becomes specialist evaluation data.

Do not jump to dynamic LoRA mixtures/routing experiments for v0.1. Keep hard host-controlled specialist switching until the baseline system is measured and qualified.

---

## 13. NEXT-THREAD OPENING STATE

Recommended continuation sentence:

> Start from `ARCADIA-main_A1_RECIPE1_STRESS_HARDENED_2026-09-03.zip`. Recipe 1 is frozen/stress-hardened. Do not modify it unless Context exposes an upstream defect. Review this handoff's proposed Context ingress/source-map/router freeze against the existing Context source-of-truth, then freeze Host Context ingress + LaneRequest before touching Evidence Specialist output.

The first substantive question to answer should be:

> **What is the smallest immutable, hash-bound Context ingress and LaneRequest contract that preserves accepted Intent and exact source provenance without reintroducing raw prompt or giving the model routing authority?**

---

# END HANDOFF
